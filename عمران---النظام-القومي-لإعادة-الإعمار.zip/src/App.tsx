/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Map as MapIcon, 
  PlusCircle, 
  Users, 
  Activity, 
  Settings,
  LogIn,
  User as UserIcon,
  AlertCircle
} from 'lucide-react';
import { signInAnonymously, signOut } from 'firebase/auth';
import { auth, useAuth } from './lib/firebase';
import { cn } from './lib/utils';
import SplashScreen from './components/SplashScreen';
import { NotificationProvider, useNotifications } from './contexts/NotificationContext';
import NotificationSettings from './components/NotificationSettings';

// Lazy load components to simulate low-bandwidth optimization
import Dashboard from './components/Dashboard';
import IssueReport from './components/IssueReport';
import Campaigns from './components/Campaigns';
import ExecutionStats from './components/ExecutionStats';
import Chatbot from './components/Chatbot';
import Profile from './components/Profile';
import InstitutionLogin from './components/InstitutionLogin';

type View = 'dashboard' | 'report' | 'campaigns' | 'stats' | 'profile';

export default function App() {
  return (
    <NotificationProvider>
      <AppContent />
    </NotificationProvider>
  );
}

function AppContent() {
  const [activeView, setActiveView] = useState<View>('dashboard');
  const [isOffline, setIsOffline] = useState(!navigator.onLine);
  const [showSplash, setShowSplash] = useState(true);
  const [showSettings, setShowSettings] = useState(false);
  const [showInstLogin, setShowInstLogin] = useState(false);
  const { user, loading } = useAuth();
  const { unreadCount } = useNotifications();

  const handleAuth = async () => {
    if (user) {
      if (confirm("هل تريد تسجيل الخروج؟")) await signOut(auth);
    } else {
      await signInAnonymously(auth);
    }
  };

  useEffect(() => {
    if (!loading && !user) {
      signInAnonymously(auth).catch(err => console.error("Anonymous auth failed:", err));
    }
  }, [user, loading]);

  useEffect(() => {
    const handleOnline = () => setIsOffline(false);
    const handleOffline = () => setIsOffline(true);
    window.addEventListener('online', handleOnline);
    window.addEventListener('offline', handleOffline);
    return () => {
      window.removeEventListener('online', handleOnline);
      window.removeEventListener('offline', handleOffline);
    };
  }, []);

  if (loading && showSplash) {
    return <SplashScreen onFinish={() => setShowSplash(false)} />;
  }

  return (
    <div className="flex flex-col h-screen w-full bg-slate-50 relative overflow-hidden font-sans" dir="rtl">
      <AnimatePresence>
        {showSplash && <SplashScreen onFinish={() => setShowSplash(false)} />}
      </AnimatePresence>

      {/* Main Structural Wrapper for Web Responsiveness */}
      <div className="flex h-full w-full max-w-[1400px] mx-auto relative shadow-2xl bg-white lg:rounded-[40px] lg:my-4 lg:h-[calc(100vh-2rem)] overflow-hidden">
        
        {/* Desktop Sidebar Navigation */}
        <aside className="hidden lg:flex w-88 bg-slate-950 flex-col p-12 text-white z-30 relative overflow-hidden">
          {/* Subtle Background Pattern for Sidebar */}
          <div className="absolute inset-0 opacity-[0.03] pointer-events-none sudan-texture scale-150 rotate-12" />
          
          <div className="flex items-center gap-6 mb-16 relative z-10">
            <div className="w-16 h-16 rounded-[24px] bg-emerald-500 flex items-center justify-center text-white shadow-[0_20px_40px_rgba(16,185,129,0.3)] -rotate-3 transition-transform hover:rotate-0 duration-500 border border-white/20">
              <MapIcon size={32} strokeWidth={2.5} />
            </div>
            <div>
              <h1 className="text-5xl font-black tracking-tighter leading-none font-display text-white">عمران</h1>
              <div className="flex items-center gap-2 mt-2">
                <div className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
                <p className="text-[10px] text-emerald-500 font-mono font-black uppercase tracking-[0.4em]">ADMIN v.03</p>
              </div>
            </div>
          </div>

          <div className="flex-1 space-y-4 relative z-10">
            <SidebarButton 
              active={activeView === 'dashboard'} 
              onClick={() => setActiveView('dashboard')}
              icon={<MapIcon size={22} />}
              label="المخطط الشامل"
            />
            <SidebarButton 
              active={activeView === 'campaigns'} 
              onClick={() => setActiveView('campaigns')}
              icon={<Users size={22} />}
              label="المبادرات الشعبية"
            />
            <SidebarButton 
              active={activeView === 'stats'} 
              onClick={() => setActiveView('stats')}
              icon={<Activity size={22} />}
              label="غرفة العمليات"
            />
            
            <div className="pt-6 mt-6 border-t border-white/5 space-y-4">
              <SidebarButton 
                active={showInstLogin} 
                onClick={() => setShowInstLogin(true)}
                icon={<LogIn size={22} />}
                label="بوابة المؤسسات"
                variant="portal"
              />
              <SidebarButton 
                active={activeView === 'profile'} 
                onClick={() => setActiveView('profile')}
                icon={<UserIcon size={22} />}
                label="مركز التحكم"
              />
              <SidebarButton 
                active={showSettings} 
                onClick={() => setShowSettings(true)}
                icon={<Settings size={22} />}
                label="الإعدادات السيادية"
                badge={unreadCount > 0 ? unreadCount : undefined}
              />
            </div>
          </div>

          <button 
            onClick={() => setActiveView('report')}
            className="w-full mt-auto py-7 bg-emerald-600 rounded-[2.5rem] font-black text-[12px] uppercase tracking-[0.3em] flex items-center justify-center gap-4 shadow-[0_20px_50px_rgba(16,185,129,0.2)] active:scale-[0.98] transition-all text-white hover:bg-emerald-500 relative z-10 border border-white/20"
          >
            <PlusCircle size={22} />
            فتح بلاغ جديد
          </button>

          <div className="mt-12 flex items-center gap-5 p-6 rounded-[2.5rem] bg-white/5 border border-white/10 relative z-10 backdrop-blur-md">
            <button onClick={handleAuth} className="w-14 h-14 rounded-2xl bg-emerald-500/20 flex items-center justify-center text-emerald-400 hover:bg-emerald-500/30 transition-all hover:scale-105 border border-emerald-500/20">
              {user ? <UserIcon size={24} /> : <LogIn size={24} />}
            </button>
            <div className="flex-1 overflow-hidden">
               <p className="text-[10px] font-black text-emerald-500/60 uppercase tracking-widest mb-1">{user ? 'هوية موثقة' : 'زيارة غير مسجلة'}</p>
               <p className="text-[14px] font-black text-white truncate leading-none">{user ? `مستخدم: ${user.uid.slice(0,8)}` : 'ضيف زائر'}</p>
            </div>
          </div>
        </aside>

        {/* Mobile Header (Hidden on LG) */}
        <div className="flex-1 flex flex-col h-full overflow-hidden relative bg-slate-50">
          <header className="lg:hidden p-5 bg-white/80 backdrop-blur-md border-b flex justify-between items-center z-10 shrink-0">
            <div className="flex items-center gap-4">
              <button onClick={() => setShowInstLogin(true)} className="w-10 h-10 border rounded-2xl text-emerald-600 flex items-center justify-center hover:bg-emerald-50 transition-colors bg-emerald-50 border-emerald-100">
                <LogIn size={20} />
              </button>
              <button onClick={handleAuth} className="w-10 h-10 border rounded-2xl text-slate-400 flex items-center justify-center hover:text-emerald-50 transition-colors bg-slate-50">
                {user ? <UserIcon size={20} /> : <LogIn size={20} />}
              </button>
              <div className="text-right">
                <h1 className="text-3xl font-black text-emerald-700 tracking-tighter leading-none font-display">عمران</h1>
                <div className="flex items-center gap-1.5 mt-1 justify-end">
                  <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse" />
                  <p className="text-[9px] text-slate-400 font-mono uppercase tracking-widest leading-none">
                    {user ? `UID: ${user.uid.slice(0,6)}` : 'GUEST MODE'}
                  </p>
                </div>
              </div>
            </div>
            {isOffline && (
              <div className="flex items-center gap-2 px-3 py-1.5 bg-rose-50 rounded-full border border-rose-100">
                <span className="w-2 h-2 bg-rose-500 rounded-full animate-pulse" />
                <span className="text-[9px] font-black text-rose-700 uppercase tracking-widest">تحت الصيانة</span>
              </div>
            )}
          </header>

          {/* Main Content Area */}
          <main className="flex-1 overflow-y-auto lg:pb-0 pb-40 relative bg-surface-sun">
            <AnimatePresence mode="wait">
              <motion.div
                key={activeView}
                initial={{ opacity: 0, y: 15, filter: 'blur(5px)' }}
                animate={{ opacity: 1, y: 0, filter: 'blur(0px)' }}
                exit={{ opacity: 0, y: -15, filter: 'blur(5px)' }}
                transition={{ type: 'spring', damping: 30, stiffness: 300 }}
                className="h-full"
              >
                {activeView === 'dashboard' && <Dashboard />}
                {activeView === 'report' && <IssueReport onComplete={() => setActiveView('dashboard')} />}
                {activeView === 'campaigns' && <Campaigns />}
                {activeView === 'stats' && <ExecutionStats />}
                {activeView === 'profile' && <Profile />}
              </motion.div>
            </AnimatePresence>
          </main>

          {/* Chatbot Activation */}
          <Chatbot extraContext={`User is looking at: ${activeView}. ${activeView === 'report' ? 'They are filing a new report.' : ''} ${activeView === 'campaigns' ? 'They are viewing community initiatives.' : ''} ${showSettings ? 'Settings modal is open.' : ''} There are ${unreadCount} unread government alerts.`} />

          {/* Mobile Navigation (Hidden on LG) - Premium Glass Design */}
          <nav className="lg:hidden fixed bottom-6 left-6 right-6 max-w-lg mx-auto bg-emerald-600/95 backdrop-blur-xl border border-emerald-400/30 px-8 py-5 rounded-[2.5rem] flex justify-between items-center z-[70] shadow-[0_32px_64px_-12px_rgba(5,150,105,0.4)]">
            <NavButton 
              active={activeView === 'dashboard'} 
              onClick={() => setActiveView('dashboard')}
              icon={<MapIcon size={24} />}
              label="الخريطة"
            />
            <NavButton 
              active={activeView === 'campaigns'} 
              onClick={() => setActiveView('campaigns')}
              icon={<Users size={24} />}
              label="الحملات"
            />
            
            {/* Primary Action - Floating with Glow */}
            <div className="relative group">
              <div className="absolute inset-0 bg-white rounded-full blur-xl opacity-20 group-hover:opacity-40 transition-opacity" />
              <button 
                onClick={() => setActiveView('report')}
                className={cn(
                  "p-5 rounded-[22px] -mt-14 shadow-2xl transition-all active:scale-95 relative z-10",
                  activeView === 'report' ? "bg-white text-emerald-600 scale-110" : "bg-white text-emerald-600"
                )}
              >
                <PlusCircle size={36} strokeWidth={2.5} />
              </button>
            </div>

            <NavButton 
              active={activeView === 'stats'} 
              onClick={() => setActiveView('stats')}
              icon={<Activity size={24} />}
              label="المتابعة"
            />
            <NavButton 
              active={showSettings} 
              onClick={() => setShowSettings(true)} 
              badge={unreadCount > 0 ? unreadCount : undefined}
              icon={<Settings size={24} />}
              label="إعدادات"
            />
          </nav>
        </div>
      </div>

      {/* Settings Modal */}
      <AnimatePresence>
        {showSettings && (
          <motion.div 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 bg-black/60 backdrop-blur-sm z-[100] flex items-end sm:items-center justify-center p-0 sm:p-6"
            onClick={() => setShowSettings(false)}
          >
            <motion.div 
              initial={{ y: '100%', scale: 0.9 }}
              animate={{ y: 0, scale: 1 }}
              exit={{ y: '100%', scale: 0.9 }}
              className="bg-white w-full max-w-md rounded-t-[40px] sm:rounded-[40px] overflow-hidden shadow-2xl"
              onClick={(e) => e.stopPropagation()}
            >
              <NotificationSettings onClose={() => setShowSettings(false)} />
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Institution Login Modal */}
      <AnimatePresence>
        {showInstLogin && (
          <motion.div 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 bg-black/80 backdrop-blur-md z-[100] flex items-center justify-center p-0 md:p-12"
            onClick={() => setShowInstLogin(false)}
          >
            <motion.div 
              initial={{ scale: 0.9, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.9, opacity: 0 }}
              className="bg-slate-950 w-full max-w-2xl h-full md:h-auto md:max-h-[90vh] md:rounded-[4rem] overflow-hidden shadow-[0_0_100px_rgba(16,185,129,0.2)] border border-white/10"
              onClick={(e) => e.stopPropagation()}
            >
              <InstitutionLogin onClose={() => setShowInstLogin(false)} />
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}

function SidebarButton({ active, onClick, icon, label, badge, variant }: { active: boolean; onClick: () => void; icon: React.ReactNode; label: string; badge?: number, variant?: 'default' | 'portal' }) {
  return (
    <button 
      onClick={onClick}
      className={cn(
        "w-full flex items-center justify-between px-7 py-6 rounded-[2.2rem] transition-all group relative overflow-hidden border-2",
        active 
          ? "bg-white text-slate-950 border-white shadow-[0_20px_40px_rgba(255,255,255,0.1)]" 
          : "text-slate-400 hover:text-white hover:bg-white/5 border-transparent",
        variant === 'portal' && !active && "bg-emerald-500/10 text-emerald-400 hover:bg-emerald-500/20 border-emerald-500/10"
      )}
    >
      <div className="flex items-center gap-5 relative z-10">
        <div className={cn("transition-colors duration-300", active ? "text-emerald-600" : "group-hover:text-emerald-400")}>
          {icon}
        </div>
        <span className="text-[13px] font-black tracking-tight uppercase tracking-[0.1em]">{label}</span>
      </div>
      {badge !== undefined && (
        <span className="bg-emerald-500 text-white text-[9px] font-black w-6 h-6 rounded-full flex items-center justify-center shadow-[0_0_15px_rgba(16,185,129,0.5)] relative z-10">
          {badge}
        </span>
      )}
    </button>
  );
}

function NavButton({ active, onClick, icon, label, badge }: { active: boolean; onClick: () => void; icon: React.ReactNode; label: string; badge?: number }) {
  return (
    <button 
      onClick={onClick}
      className={cn(
        "flex flex-col items-center gap-1.5 transition-all relative flex-1 min-w-0 duration-500",
        active ? "text-white" : "text-white/40 hover:text-white/70"
      )}
    >
      <div className="relative">
        <div className={cn(
          "transition-all duration-300",
          active ? "scale-110 -translate-y-0.5" : "scale-100 translate-y-0"
        )}>
          {icon}
        </div>
        {badge !== undefined && (
          <span className="absolute -top-1.5 -right-2 bg-rose-500 text-white text-[8px] font-black w-4 h-4 rounded-full flex items-center justify-center border border-emerald-600 shadow-lg">
            {badge}
          </span>
        )}
      </div>
      <span className={cn(
        "text-[8px] font-black uppercase tracking-[0.2em] leading-none transition-all duration-300",
        active ? "opacity-100 translate-y-0" : "opacity-0 translate-y-1"
      )}>{label}</span>
      {active && (
        <motion.div 
          layoutId="nav-glow"
          className="absolute -bottom-5 w-6 h-1 bg-white rounded-full shadow-[0_0_15px_rgba(255,255,255,0.5)]"
        />
      )}
    </button>
  );
}
