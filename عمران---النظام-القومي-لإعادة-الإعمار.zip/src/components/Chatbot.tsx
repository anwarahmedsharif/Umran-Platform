import React, { useState, useRef, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { MessageSquare, X, Send, User, Bot, Loader2, Mic, Square, Volume2, Headphones } from 'lucide-react';
import { getSudaneseChatResponse, translateVoiceReport } from '../services/geminiService';
import { cn } from '../lib/utils';
import VoiceAssistant from './VoiceAssistant';

interface Message {
  role: 'user' | 'model';
  content: string;
  isVoice?: boolean;
}

export default function Chatbot({ extraContext }: { extraContext?: string }) {
  const [isOpen, setIsOpen] = useState(false);
  const [messages, setMessages] = useState<Message[]>([
    { role: 'model', content: 'حبابك يا زول! أنا مساعد عمران، ممكن أساعدك في شنو الليلة؟' }
  ]);
  const [input, setInput] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [isVoiceMode, setIsVoiceMode] = useState(false);
  const [isRecording, setIsRecording] = useState(false);
  const scrollRef = useRef<HTMLDivElement>(null);
  const mediaRecorderRef = useRef<MediaRecorder | null>(null);
  const chunksRef = useRef<Blob[]>([]);

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [messages]);

  const startRecording = async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      const recorder = new MediaRecorder(stream);
      mediaRecorderRef.current = recorder;
      chunksRef.current = [];

      recorder.ondataavailable = (e) => {
        if (e.data.size > 0) chunksRef.current.push(e.data);
      };

      recorder.onstop = async () => {
        const audioBlob = new Blob(chunksRef.current, { type: 'audio/webm' });
        await handleVoiceMessage(audioBlob);
        stream.getTracks().forEach(track => track.stop());
      };

      recorder.start();
      setIsRecording(true);
    } catch (err) {
      console.error("Failed to start recording", err);
      alert("لا يمكن الوصول للميكروفون. يرجى التأكد من الصلاحيات.");
    }
  };

  const stopRecording = () => {
    if (mediaRecorderRef.current && isRecording) {
      mediaRecorderRef.current.stop();
      setIsRecording(false);
    }
  };

  const handleVoiceMessage = async (blob: Blob) => {
    setIsLoading(true);
    setMessages(prev => [...prev, { role: 'user', content: 'جاري معالجة التسجيل الصوتي...', isVoice: true }]);

    const reader = new FileReader();
    reader.readAsDataURL(blob);
    reader.onloadend = async () => {
      const base64Audio = (reader.result as string).split(',')[1];
      const translation = await translateVoiceReport(base64Audio);

      if (translation) {
        // Replace the "processing" message with the translated text
        setMessages(prev => {
          const newMsgs = [...prev];
          newMsgs[newMsgs.length - 1] = { role: 'user', content: translation, isVoice: true };
          return newMsgs;
        });

        const history = messages.map(m => ({
          role: m.role,
          parts: [{ text: m.content }]
        }));

        const context = `${extraContext || ''} | The user just submitted a voice note which was translated.`;
        const response = await getSudaneseChatResponse(translation, history, context);
        setMessages(prev => [...prev, { role: 'model', content: response }]);
      } else {
        setMessages(prev => [...prev, { role: 'model', content: 'معليش يا زول، ما قدرت أفهم التسجيل. ممكن تجرب تاني؟' }]);
      }
      setIsLoading(false);
    };
  };

  const handleSend = async () => {
    if (!input.trim() || isLoading) return;

    const userMsg = input.trim();
    setInput('');
    setMessages(prev => [...prev, { role: 'user', content: userMsg }]);
    setIsLoading(true);

    const history = messages.map(m => ({
      role: m.role,
      parts: [{ text: m.content }]
    }));

    const context = `${extraContext || ''} | User is interacting in the main chat.`;
    
    const response = await getSudaneseChatResponse(userMsg, history, context);
    setMessages(prev => [...prev, { role: 'model', content: response }]);
    setIsLoading(false);
  };

  return (
    <>
      {/* Floating Button */}
      <button 
        onClick={() => setIsOpen(true)}
        className="fixed bottom-32 lg:bottom-12 right-6 lg:right-12 w-16 h-16 bg-slate-900 text-white rounded-full shadow-[0_20px_50px_rgba(0,0,0,0.3)] flex items-center justify-center hover:scale-110 active:scale-95 transition-all z-[80] group overflow-hidden border border-white/20"
      >
        <div className="absolute inset-0 bg-gradient-to-tr from-emerald-600/20 to-transparent opacity-0 group-hover:opacity-100 transition-opacity" />
        <MessageSquare size={26} className="relative z-10" />
      </button>

      {/* Chat Window */}
      <AnimatePresence>
        {isOpen && (
          <motion.div 
            initial={{ opacity: 0, y: 100, scale: 0.9 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: 100, scale: 0.9 }}
            className="fixed inset-0 sm:inset-auto sm:bottom-32 sm:right-6 sm:w-[420px] sm:h-[650px] bg-white sm:rounded-[32px] shadow-2xl flex flex-col z-[100] overflow-hidden border border-slate-100"
          >
            {/* Header */}
            <div className="p-5 bg-slate-900 text-white flex justify-between items-center relative overflow-hidden">
              <div className="absolute inset-0 opacity-10 sudan-texture pointer-events-none" />
              <div className="flex items-center gap-3 relative z-10">
                <div className="w-12 h-12 bg-emerald-500 rounded-2xl flex items-center justify-center border-2 border-white/20 shadow-lg rotate-3 group-hover:rotate-0 transition-transform">
                  <Bot size={28} />
                </div>
                <div>
                  <h3 className="font-black text-sm font-display tracking-tight">مساعد عمران الذكي</h3>
                  <div className="flex items-center gap-1.5">
                    <div className="w-1.5 h-1.5 bg-emerald-400 rounded-full animate-pulse" />
                    <p className="text-[9px] text-emerald-400 font-black uppercase tracking-[0.2em]">نشط الآن</p>
                  </div>
                </div>
              </div>
              <div className="flex items-center gap-2 relative z-10">
                <button 
                  onClick={() => setIsVoiceMode(true)}
                  className="p-2.5 hover:bg-white/10 rounded-xl transition-all text-emerald-400"
                  title="المساعد الصوتي المتقدم"
                >
                  <Headphones size={20} />
                </button>
                <button 
                  onClick={() => setIsOpen(false)}
                  className="p-2.5 hover:bg-white/10 rounded-xl transition-all"
                >
                  <X size={20} />
                </button>
              </div>
            </div>

            {/* Voice Assistant Overlay (Full Screen Dialogue) */}
            <AnimatePresence>
              {isVoiceMode && (
                <VoiceAssistant onClose={() => setIsVoiceMode(false)} />
              )}
            </AnimatePresence>

            {/* Messages */}
            <div 
              ref={scrollRef}
              className="flex-1 p-5 overflow-y-auto bg-slate-50 space-y-6 relative"
            >
              <div className="absolute inset-0 opacity-[0.02] sudan-texture pointer-events-none" />
              
              {messages.map((m, i) => (
                <motion.div 
                  initial={{ opacity: 0, y: 10, scale: 0.95 }}
                  animate={{ opacity: 1, y: 0, scale: 1 }}
                  key={i} 
                  className={cn(
                    "flex flex-col max-w-[85%] relative z-10",
                    m.role === 'user' ? "mr-auto items-end" : "ml-auto items-start"
                  )}
                >
                  <div className={cn(
                    "p-4 rounded-[24px] text-sm shadow-sm leading-relaxed",
                    m.role === 'user' 
                      ? "bg-emerald-600 text-white rounded-tr-none font-bold" 
                      : "bg-white text-slate-700 border border-slate-100 rounded-tl-none font-medium shadow-md shadow-slate-100"
                  )}>
                    {m.isVoice && m.role === 'user' && (
                      <div className="flex items-center gap-2 mb-2 pb-2 border-b border-white/20 opacity-80">
                         <Volume2 size={14} />
                         <span className="text-[10px] font-black uppercase tracking-widest text-right">تقرير صوتي مترجم</span>
                      </div>
                    )}
                    {m.content}
                  </div>
                  <span className="text-[8px] font-black text-slate-300 mt-1 uppercase tracking-widest">
                    {m.role === 'user' ? 'أنت' : 'مساعد عمران'}
                  </span>
                </motion.div>
              ))}
              {isLoading && (
                <div className="flex items-center gap-2 text-slate-400 text-[10px] font-black uppercase tracking-widest italic py-2">
                  <div className="flex gap-1">
                    <div className="w-1 h-1 bg-emerald-500 rounded-full animate-bounce" style={{ animationDelay: '0ms' }} />
                    <div className="w-1 h-1 bg-emerald-500 rounded-full animate-bounce" style={{ animationDelay: '150ms' }} />
                    <div className="w-1 h-1 bg-emerald-500 rounded-full animate-bounce" style={{ animationDelay: '300ms' }} />
                  </div>
                  جاري التحليل...
                </div>
              )}
            </div>

            {/* Input Bar */}
            <div className="p-4 bg-white border-t border-slate-100">
              <div className="flex items-center gap-3">
                <div className="flex-1 relative flex items-center">
                   <button 
                    onMouseDown={startRecording}
                    onMouseUp={stopRecording}
                    onTouchStart={startRecording}
                    onTouchEnd={stopRecording}
                    className={cn(
                      "absolute left-2 p-2 rounded-full transition-all",
                      isRecording ? "bg-red-500 text-white animate-pulse" : "text-slate-400 hover:text-emerald-600 hover:bg-slate-50"
                    )}
                    title="تحدث للإبلاغ"
                  >
                    {isRecording ? <Square size={16} /> : <Mic size={20} />}
                  </button>
                  <input 
                    type="text" 
                    dir="rtl"
                    placeholder={isRecording ? "جاري التسجيل..." : "اسأل عن الإعمار أو ارسل بصمة..."}
                    className="w-full pl-10 pr-4 py-3.5 bg-slate-50 border-none rounded-[22px] text-sm font-medium outline-none focus:ring-2 focus:ring-emerald-500 transition-all placeholder:text-slate-300"
                    value={input}
                    onChange={(e) => setInput(e.target.value)}
                    onKeyDown={(e) => e.key === 'Enter' && handleSend()}
                    disabled={isRecording}
                  />
                </div>
                <button 
                  onClick={handleSend}
                  disabled={!input.trim() || isLoading || isRecording}
                  className="w-12 h-12 bg-slate-900 text-white rounded-2xl flex items-center justify-center disabled:opacity-50 transition-all active:scale-95 shadow-xl shadow-slate-100"
                >
                  <Send size={20} />
                </button>
              </div>
              {isRecording && (
                <motion.p 
                  initial={{ opacity: 0, y: 5 }}
                  animate={{ opacity: 1, y: 0 }}
                  className="text-center text-[9px] font-black text-red-500 uppercase tracking-widest mt-2"
                >
                  ارفع يدك عند الانتهاء من التسجيل
                </motion.p>
              )}
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </>
  );
}
