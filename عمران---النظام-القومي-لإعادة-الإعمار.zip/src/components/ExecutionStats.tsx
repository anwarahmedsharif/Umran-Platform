import React, { useState } from 'react';
import { motion } from 'motion/react';
import { 
  BarChart, 
  Bar, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  ResponsiveContainer,
  PieChart,
  Pie,
  Cell
} from 'recharts';
import { CheckCircle, Clock, AlertTriangle, TrendingUp, Trophy, Building2, ShieldCheck, ArrowUpRight } from 'lucide-react';
import { cn } from '../lib/utils';

import { INSTITUTIONS } from '../constants';

const DATA = [
  { name: 'الطرق', count: 45 },
  { name: 'المياه', count: 32 },
  { name: 'الكهرباء', count: 18 },
  { name: 'النفايات', count: 28 },
];

const PIE_DATA = [
  { name: 'مكتمل', value: 400, color: '#10b981' },
  { name: 'قيد المراجعة', value: 300, color: '#f59e0b' },
  { name: 'تحت التنفيذ', value: 200, color: '#ef4444' },
];

const INSTITUTIONAL_KPI_MAPPING = [
  { id: 'roads', score: 92, speed: '١.٥ يوم', trend: '+٥٪' },
  { id: 'electricity', score: 88, speed: '٢.٢ يوم', trend: '+٢٪' },
  { id: 'water', score: 84, speed: '٣.١ يوم', trend: '-١٪' },
  { id: 'environment', score: 79, speed: '٤.٠ يوم', trend: '+٨٪' }
];

export default function ExecutionStats() {
  return (
    <div className="p-6 space-y-8 pb-32 overflow-y-auto h-full" dir="rtl">
      <div className="space-y-1 text-right">
        <h2 className="text-2xl font-black font-display italic tracking-tight text-slate-800">مركز الشفافية والمساءلة</h2>
        <p className="text-[11px] font-black text-emerald-600 uppercase tracking-widest leading-none">متابعة أداء المؤسسات والالتزام بالحلول</p>
      </div>

      {/* Primary KPI Grid */}
      <div className="grid grid-cols-2 gap-4">
        <MetricCard 
          icon={<ShieldCheck className="text-emerald-500" size={18} />}
          label="الالتزام بالوقت (SLA)"
          value="٨٤٪"
          delta="+٤٪"
        />
        <MetricCard 
          icon={<Clock className="text-amber-500" size={18} />}
          label="متوسط سرعة الرد"
          value="٢.٤ يوم"
          delta="-٠.٣ يوم"
        />
        <MetricCard 
          icon={<AlertTriangle className="text-red-500" size={18} />}
          label="حالات عالية الأهمية"
          value="١٨"
          delta="نشط"
        />
        <MetricCard 
          icon={<CheckCircle className="text-blue-500" size={18} />}
          label="رضا المواطنين"
          value="٤.٦ / ٥"
          delta="ممتاز"
        />
      </div>

      {/* Institutional Leaderboard (Tajawob Clone) */}
      <div className="space-y-4">
        <div className="flex items-center justify-between">
          <h3 className="text-[10px] font-black text-slate-400 uppercase tracking-widest text-right">مؤشر أداء المؤسسات</h3>
          <Trophy size={14} className="text-amber-400" />
        </div>
        
        <div className="space-y-3">
          {INSTITUTIONAL_KPI_MAPPING.map((kpi, idx) => {
            const inst = INSTITUTIONS.find(i => i.id === kpi.id);
            if (!inst) return null;
            
            return (
              <motion.div 
                key={inst.id}
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: idx * 0.1 }}
                className="p-5 bg-white border border-slate-100 rounded-[28px] shadow-sm hover:shadow-md transition-all group"
              >
                <div className="flex justify-between items-center flex-row-reverse">
                  <div className="flex items-center gap-3">
                    <div className="text-right">
                      <h4 className="text-sm font-black text-slate-900 group-hover:text-emerald-600 transition-colors uppercase tracking-tight">{inst.fullName}</h4>
                      <p className="text-[9px] text-slate-400 font-bold uppercase tracking-widest italic">سرعة الاستجابة: {kpi.speed}</p>
                    </div>
                    <div className="w-12 h-12 bg-slate-50 border border-slate-100 rounded-2xl flex items-center justify-center overflow-hidden transition-all group-hover:border-emerald-500 group-hover:scale-105">
                      {inst.logo ? (
                        <img src={inst.logo} className="w-full h-full object-cover" referrerPolicy="no-referrer" />
                      ) : (
                        <Building2 size={24} className="text-slate-300" />
                      )}
                    </div>
                  </div>
                  
                  <div className="text-left">
                    <div className="text-lg font-black font-mono text-slate-900">{kpi.score}%</div>
                    <div className={cn(
                      "text-[9px] font-black uppercase tracking-widest",
                      kpi.trend.startsWith('+') ? "text-emerald-500" : "text-amber-500"
                    )}>{kpi.trend}</div>
                  </div>
                </div>
                
                <div className="mt-4 h-1.5 bg-slate-50 rounded-full overflow-hidden">
                  <motion.div 
                    initial={{ width: 0 }}
                    animate={{ width: `${kpi.score}%` }}
                    className="h-full bg-emerald-500 rounded-full"
                  />
                </div>
              </motion.div>
            );
          })}
        </div>
      </div>

      {/* Category Chart */}
      <div className="bg-white border border-slate-100 rounded-[40px] p-8 h-80 shadow-sm relative overflow-hidden">
        <div className="absolute top-0 right-0 w-32 h-full opacity-[0.02] pointer-events-none sudan-texture" />
        <h3 className="text-[10px] font-black text-slate-400 uppercase tracking-widest mb-6 text-right relative z-10">توزيع البلاغات النشطة</h3>
        <ResponsiveContainer width="100%" height="100%">
          <BarChart data={DATA}>
            <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f1f5f9" />
            <XAxis dataKey="name" axisLine={false} tickLine={false} tick={{ fontSize: 10, fill: '#94a3b8', fontWeight: 900 }} />
            <Tooltip 
              cursor={{ fill: 'rgba(16, 185, 129, 0.05)', radius: 12 }}
              contentStyle={{ borderRadius: '24px', border: 'none', boxShadow: '0 20px 25px -5px rgb(0 0 0 / 0.1)', textAlign: 'right', padding: '16px' }}
            />
            <Bar dataKey="count" fill="#10b981" radius={[12, 12, 0, 0]} barSize={40} />
          </BarChart>
        </ResponsiveContainer>
      </div>

      {/* Global Impact */}
      <div className="p-8 bento-inner bg-white border-2 border-emerald-500 rounded-[40px] space-y-4 shadow-xl shadow-emerald-500/10 relative overflow-hidden group">
         <div className="absolute top-0 right-0 w-32 h-full opacity-[0.05] pointer-events-none sudan-texture" />
         <div className="flex justify-between items-center flex-row-reverse relative z-10">
            <h3 className="text-xl font-black font-display italic text-slate-800">كفاءة الحلول</h3>
            <span className="text-[10px] font-black text-emerald-600 uppercase tracking-widest bg-emerald-50 px-3 py-1 rounded-full border border-emerald-100">تحديث مباشر</span>
         </div>
         <div className="flex items-end gap-4 flex-row-reverse relative z-10">
            <div className="text-5xl font-black font-mono text-emerald-600">٧٨.٤٪</div>
            <div className="pb-2 text-emerald-500 flex items-center gap-1 text-[10px] font-black underline decoration-emerald-200 underline-offset-4">
               <ArrowUpRight size={14} />
               <span>+٥.٢٪ هذا الشهر</span>
            </div>
         </div>
         <p className="text-xs text-slate-500 font-medium leading-relaxed text-right italic font-content relative z-10">
            تحسن ملحوظ في سرعة معالجة بلاغات المياه والكهرباء بعد تفعيل نظام المتابعة الرقمي الموحد.
         </p>
      </div>
    </div>
  );
}

function MetricCard({ icon, label, value, delta }: { icon: React.ReactNode; label: string, value: string, delta: string }) {
  return (
    <div className="bg-white border border-slate-100 rounded-[32px] p-5 space-y-2 shadow-sm text-right relative overflow-hidden group hover:border-emerald-500 transition-colors">
      <div className="absolute top-0 right-0 w-8 h-8 bg-emerald-500/5 rounded-bl-3xl -translate-y-2 translate-x-2 transition-transform group-hover:translate-y-0 group-hover:translate-x-0" />
      <div className="flex justify-between items-center flex-row-reverse relative z-10">
        <div className="p-2.5 bg-slate-50 rounded-xl text-slate-400 group-hover:bg-emerald-50 group-hover:text-emerald-600 transition-colors">
           {icon}
        </div>
        <span className={cn(
          "text-[8px] font-black px-2 py-0.5 rounded-full uppercase tracking-widest",
          delta.startsWith('+') ? "bg-emerald-50 text-emerald-600" :
          delta.startsWith('-') ? "bg-blue-50 text-blue-600" : "bg-slate-50 text-slate-500"
        )}>{delta}</span>
      </div>
      <div className="text-2xl font-black font-mono text-slate-900">{value}</div>
      <div className="text-[9px] font-black text-slate-400 uppercase tracking-[0.15em]">{label}</div>
    </div>
  );
}
