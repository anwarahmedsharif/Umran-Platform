import React, { useState, useEffect, useRef } from 'react';
import { motion } from 'motion/react';
import { setOptions, importLibrary } from '@googlemaps/js-api-loader';
import { 
  Search, 
  MapPin, 
  Filter, 
  TrendingUp,
  MoreVertical, 
  ThumbsUp, 
  MessageSquare, 
  Share2,
  Activity,
  Loader2,
  AlertTriangle,
  X,
  Bell,
  Wallet,
  Grid,
  Trophy,
  Truck,
  Droplets,
  Zap,
  Trash2,
  History,
  Map as MapIcon,
  ShieldCheck,
  Check,
  Building,
  HelpCircle,
  ArrowUpRight
} from 'lucide-react';
import { collection, query, orderBy, limit, onSnapshot } from 'firebase/firestore';
import { db } from '../lib/firebase';
import { cn, formatTimeAgo } from '../lib/utils';
import { Issue } from '../types';
import { INSTITUTIONS } from '../constants';
import IssueDetail from './IssueDetail';
import AlertsList from './Alerts';
import UtilityPayments from './Payments';
import RegionalCompetition from './RegionalCompetition';
import { AnimatePresence } from 'motion/react';
import { MapContainer, TileLayer, Marker as LeafletMarker, Popup } from 'react-leaflet';
import L from 'leaflet';
import 'leaflet/dist/leaflet.css';

// Fix Leaflet marker icons
delete (L.Icon.Default.prototype as any)._getIconUrl;
L.Icon.Default.mergeOptions({
  iconRetinaUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.7.1/images/marker-icon-2x.png',
  iconUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.7.1/images/marker-icon.png',
  shadowUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.7.1/images/marker-shadow.png',
});

type DashboardTab = 'activity' | 'alerts' | 'payments' | 'compete' | 'archive';

export default function Dashboard() {
  const [issues, setIssues] = useState<Issue[]>([]);
  const [loading, setLoading] = useState(true);
  const [selectedIssue, setSelectedIssue] = useState<Issue | null>(null);
  const [activeMarkerIssue, setActiveMarkerIssue] = useState<Issue | null>(null);
  const [activeTab, setActiveTab] = useState<DashboardTab>('activity');
  const [selectedInstitution, setSelectedInstitution] = useState<string>('all');
  const [showFilters, setShowFilters] = useState(false);
  const [isMapLoaded, setIsMapLoaded] = useState(false);
  const [mapError, setMapError] = useState<string | null>(null);
  
  const mapRef = useRef<HTMLDivElement>(null);
  const googleMapRef = useRef<google.maps.Map | null>(null);
  const markersRef = useRef<google.maps.Marker[]>([]);

  const filteredIssues = issues.filter(issue => {
    // If specifically set to false, it might be an official/system report, but default to showing it
    if (issue.reportedByCitizen === false) return false;
    
    if (selectedInstitution === 'all') return true;
    if (selectedInstitution === 'unassigned') return !issue.assignedInstitution;
    return issue.assignedInstitution === selectedInstitution;
  });

  const getIssueIcon = (type: string, size = 20) => {
    switch(type) {
      case 'road': return <Truck size={size} />;
      case 'water': return <Droplets size={size} />;
      case 'electricity': return <Zap size={size} />;
      case 'waste': return <Trash2 size={size} />;
      case 'other': return <HelpCircle size={size} />;
      default: return <Activity size={size} />;
    }
  };

  const handleMarkerClick = (issue: Issue) => {
    if (googleMapRef.current) {
      googleMapRef.current.setZoom(16);
      googleMapRef.current.panTo({ lat: issue.location.lat, lng: issue.location.lng });
    }
    setActiveMarkerIssue(issue);
  };

  const resetMap = () => {
    if (googleMapRef.current) {
      googleMapRef.current.setZoom(12);
      googleMapRef.current.setCenter({ lat: 15.5, lng: 32.55 });
    }
    setActiveMarkerIssue(null);
  };

  useEffect(() => {
    // Add global handler for Google Maps Auth Failure
    (window as any).gm_authFailure = () => {
      console.error("Google Maps authentication failed (gm_authFailure)");
      setMapError('ApiProjectMapError');
    };

    // Generic error listener to catch script errors from Google Maps
    const handleError = (e: ErrorEvent) => {
      if (e.message?.includes('google') || e.filename?.includes('maps.googleapis.com')) {
        console.warn("Caught potential Google Maps script error:", e.message);
        setMapError('ApiProjectMapError');
      }
    };
    window.addEventListener('error', handleError);

    const apiKey = (import.meta as any).env.VITE_GOOGLE_MAPS_API_KEY;
    const isInvalidKey = !apiKey || apiKey === 'YOUR_KEY_HERE' || apiKey.trim() === '';

    if (isInvalidKey) {
      console.warn("Google Maps API Key is missing or default. Using Leaflet fallback.");
      setMapError('missing_key');
      return () => window.removeEventListener('error', handleError);
    }

    setOptions({
      apiKey: apiKey,
      version: 'weekly',
    } as any);

    let mapInitTimeout: any;

    const initMap = async () => {
      // Set a safety timeout for map initialization
      mapInitTimeout = setTimeout(() => {
        if (!isMapLoaded) {
          console.warn("Google Maps initialization timed out. Using fallback.");
          setMapError('timeout');
        }
      }, 10000);

      try {
        const { Map } = await importLibrary('maps') as google.maps.MapsLibrary;
        await importLibrary('marker');

        if (mapRef.current) {
          const map = new Map(mapRef.current, {
            center: { lat: 15.5007, lng: 32.5599 },
            zoom: 12,
            disableDefaultUI: true,
            styles: [
            {
              "featureType": "all",
              "elementType": "geometry.fill",
              "stylers": [{ "weight": "2.00" }]
            },
            {
              "featureType": "all",
              "elementType": "geometry.stroke",
              "stylers": [{ "color": "#9c9c9c" }]
            },
            {
              "featureType": "all",
              "elementType": "labels.text",
              "stylers": [{ "visibility": "on" }]
            },
            {
              "featureType": "landscape",
              "elementType": "all",
              "stylers": [{ "color": "#f2f2f2" }]
            },
            {
              "featureType": "landscape",
              "elementType": "geometry.fill",
              "stylers": [{ "color": "#ffffff" }]
            },
            {
              "featureType": "landscape.man_made",
              "elementType": "geometry.fill",
              "stylers": [{ "color": "#ffffff" }]
            },
            {
              "featureType": "poi",
              "elementType": "all",
              "stylers": [{ "visibility": "off" }]
            },
            {
              "featureType": "road",
              "elementType": "all",
              "stylers": [{ "saturation": -100 }, { "lightness": 45 }]
            },
            {
              "featureType": "road",
              "elementType": "geometry.fill",
              "stylers": [{ "color": "#eeeeee" }]
            },
            {
              "featureType": "road",
              "elementType": "labels.text.fill",
              "stylers": [{ "color": "#7b7b7b" }]
            },
            {
              "featureType": "road",
              "elementType": "labels.text.stroke",
              "stylers": [{ "color": "#ffffff" }]
            },
            {
              "featureType": "road.highway",
              "elementType": "all",
              "stylers": [{ "visibility": "simplified" }]
            },
            {
              "featureType": "road.arterial",
              "elementType": "labels.icon",
              "stylers": [{ "visibility": "off" }]
            },
            {
              "featureType": "transit",
              "elementType": "all",
              "stylers": [{ "visibility": "off" }]
            },
            {
              "featureType": "water",
              "elementType": "all",
              "stylers": [{ "color": "#46bcec" }, { "visibility": "on" }]
            },
            {
              "featureType": "water",
              "elementType": "geometry.fill",
              "stylers": [{ "color": "#c8d7d4" }]
            },
            {
              "featureType": "water",
              "elementType": "labels.text.fill",
              "stylers": [{ "color": "#070707" }]
            },
            {
              "featureType": "water",
              "elementType": "labels.text.stroke",
              "stylers": [{ "color": "#ffffff" }]
            }
          ]
        });
        googleMapRef.current = map;
        clearTimeout(mapInitTimeout);
        setIsMapLoaded(true);
        setMapError(null);
      }
    } catch (error: any) {
      clearTimeout(mapInitTimeout);
      console.error("Google Maps initialization failed:", error);
      setMapError(error.message || 'initialization_failed');
    }
  };

  initMap();

  return () => {
    window.removeEventListener('error', handleError);
    if (mapInitTimeout) clearTimeout(mapInitTimeout);
  };
}, []);

  useEffect(() => {
    if (!isMapLoaded || !googleMapRef.current) return;

    // Clear existing markers
    markersRef.current.forEach(marker => marker.setMap(null));
    markersRef.current = [];

    // Add new markers
    filteredIssues.forEach(issue => {
      // Safety check for google object
      if (typeof google === 'undefined' || !google.maps) return;

      const getMarkerColor = (severity: number) => {
        if (severity === 3) return '#ef4444'; // Red for urgent
        if (severity === 2) return '#f59e0b'; // Amber for important
        return '#10b981'; // Emerald for normal
      };

      const color = getMarkerColor(issue.severity);
      
      const getCategoryInitial = (type: string) => {
        switch (type) {
          case 'road': return 'ط';
          case 'water': return 'م';
          case 'electricity': return 'ك';
          case 'waste': return 'ن';
          default: return 'أ';
        }
      };

      // Modern Pin SVG
      const svgMarker = {
        path: "M 0,0 C -2,-20 -10,-22 -10,-30 A 10,10 0 1,1 10,-30 C 10,-22 2,-20 0,0 z",
        fillColor: color,
        fillOpacity: 1,
        strokeColor: '#FFFFFF',
        strokeWeight: 3,
        scale: 1.5,
        labelOrigin: new google.maps.Point(0, -30)
      };
      
      const marker = new google.maps.Marker({
        position: { lat: issue.location.lat, lng: issue.location.lng },
        map: googleMapRef.current,
        title: issue.description,
        icon: svgMarker,
        label: {
          text: getCategoryInitial(issue.type),
          color: '#FFFFFF',
          fontSize: '12px',
          fontWeight: '900'
        },
        animation: issue.severity === 3 ? google.maps.Animation.BOUNCE : undefined
      });

      // Stop bouncing after a few seconds if it's urgent
      if (issue.severity === 3) {
        setTimeout(() => {
          marker.setAnimation(null);
        }, 3000);
      }

      marker.addListener('click', () => {
        handleMarkerClick(issue);
      });

      markersRef.current.push(marker);
    });
  }, [filteredIssues, isMapLoaded]);

  useEffect(() => {
    const q = query(collection(db, 'issues'), orderBy('createdAt', 'desc'), limit(50));
    const unsubscribe = onSnapshot(q, (snapshot) => {
      const fetchedIssues = snapshot.docs.map(doc => ({
        id: doc.id,
        ...doc.data()
      })) as any[];
      setIssues(fetchedIssues);
      setLoading(false);
    }, (error) => {
      console.error("Error fetching issues:", error);
      setLoading(false);
    });

    return () => unsubscribe();
  }, []);


  return (
    <div className="h-full flex flex-col relative" dir="rtl">
      {/* Sudanese Pattern Overlay (Top) */}
      <div className="absolute top-0 inset-x-0 h-40 opacity-[0.03] pointer-events-none sudan-texture" />

      {/* Header & Welcome - Hidden on mobile to avoid double headers */}
      <div className="hidden lg:block px-12 pt-16 pb-8 space-y-2 relative z-10">
        <div className="flex justify-between items-center mb-8">
          <div className="flex items-center gap-3">
             <div className="w-3 h-3 rounded-full bg-emerald-500 shadow-[0_0_15px_rgba(16,185,129,0.5)] animate-pulse" />
             <p className="text-[10px] font-black text-emerald-900 uppercase tracking-[0.4em] font-mono italic">OPERATIONAL // SUDAN</p>
          </div>
          <div className="text-left">
             <span className="text-[10px] font-black text-slate-400 uppercase tracking-[0.3em] font-mono">
               DATABASE SYNC: {new Date().toLocaleTimeString('ar-SD')}
             </span>
          </div>
        </div>
        
        <div className="flex flex-col lg:flex-row lg:items-end justify-between gap-6">
          <div className="max-w-2xl">
            <h1 className="text-6xl lg:text-8xl font-black text-slate-900 tracking-tighter font-display mb-4 leading-[0.85]">
              عُـمْـران <span className="text-emerald-500">.</span>
            </h1>
            <p className="text-lg lg:text-xl text-slate-500 font-medium font-content max-w-xl leading-relaxed lg:pr-2 border-r-4 border-emerald-500/10">
              النظام القومي لإعادة الإعمار والتنمية الرقمية الشاملة. 
              نجمع الأيادي لنبني وطناً يليق بتطلعاتنا.
            </p>
          </div>
          
          <div className="flex items-center gap-4 bg-white p-2 rounded-[2rem] border border-slate-100 shadow-sm">
             <div className="w-12 h-12 bg-slate-50 rounded-2xl flex items-center justify-center text-slate-400">
                <MapPin size={22} />
             </div>
             <div className="pr-2 pl-6">
                <p className="text-[9px] font-black text-slate-400 uppercase tracking-widest mb-0.5">الموقع الحالي</p>
                <p className="text-xs font-black text-slate-900 tracking-tight">الخرطوم، السودان</p>
             </div>
          </div>
        </div>
      </div>

      {/* Stats Bento - Precise KPI View */}
      <div className="px-5 lg:px-12 py-6 lg:py-10 grid grid-cols-2 lg:grid-cols-4 gap-4 lg:gap-6 relative z-10">
        <div className="bg-white border-2 border-slate-950 p-6 lg:p-8 rounded-[2.5rem] group hover:bg-slate-950 transition-all duration-500 shadow-[8px_8px_0_0_#10b981]">
          <div className="flex justify-between items-start mb-6">
             <Activity className="text-emerald-600 group-hover:text-emerald-400" size={32} strokeWidth={2.5} />
             <div className="p-1 px-2 rounded-full bg-emerald-50 text-[9px] font-black text-emerald-600 uppercase tracking-widest">LIVE</div>
          </div>
          <p className="text-4xl lg:text-5xl font-black text-slate-900 group-hover:text-white tracking-tighter mb-2 font-mono">١٢</p>
          <p className="text-[11px] font-black text-slate-400 group-hover:text-emerald-400/60 uppercase tracking-widest">البلاغات النشطة</p>
        </div>

        <div className="bg-white border-2 border-slate-950 p-6 lg:p-8 rounded-[2.5rem] group hover:bg-slate-950 transition-all duration-500 shadow-[8px_8px_0_0_#3b82f6]">
          <div className="flex justify-between items-start mb-6">
             <ThumbsUp className="text-blue-500 group-hover:text-blue-400" size={32} strokeWidth={2.5} />
             <div className="p-1 px-2 rounded-full bg-blue-50 text-[9px] font-black text-blue-600 uppercase tracking-widest">+١٨٪</div>
          </div>
          <p className="text-4xl lg:text-5xl font-black text-slate-900 group-hover:text-white tracking-tighter mb-2 font-mono">٢٤٥</p>
          <p className="text-[11px] font-black text-slate-400 group-hover:text-blue-400/60 uppercase tracking-widest">المساهمات المجتمعية</p>
        </div>

        <div className="bg-white border-2 border-slate-950 p-6 lg:p-8 rounded-[2.5rem] group hover:bg-slate-950 transition-all duration-500 shadow-[8px_8px_0_0_#f59e0b]">
          <div className="flex justify-between items-start mb-6">
             <ShieldCheck className="text-amber-500 group-hover:text-amber-400" size={32} strokeWidth={2.5} />
             <div className="p-1 px-2 rounded-full bg-amber-50 text-[9px] font-black text-amber-600 uppercase tracking-widest">SECURE</div>
          </div>
          <p className="text-4xl lg:text-5xl font-black text-slate-900 group-hover:text-white tracking-tighter mb-2 font-mono">١٠٠٪</p>
          <p className="text-[11px] font-black text-slate-400 group-hover:text-amber-400/60 uppercase tracking-widest">سلامة الأنظمة</p>
        </div>

        <div className="bg-white border-2 border-slate-950 p-6 lg:p-8 rounded-[2.5rem] group hover:bg-slate-950 transition-all duration-500 shadow-[8px_8px_0_0_#f43f5e]">
          <div className="flex justify-between items-start mb-6">
             <Trophy className="text-rose-500 group-hover:text-rose-400" size={32} strokeWidth={2.5} />
             <div className="p-1 px-2 rounded-full bg-rose-50 text-[9px] font-black text-rose-600 uppercase tracking-widest">RANK ١</div>
          </div>
          <p className="text-4xl lg:text-5xl font-black text-slate-900 group-hover:text-white tracking-tighter mb-2 font-mono">٨.٤</p>
          <p className="text-[11px] font-black text-slate-400 group-hover:text-rose-400/60 uppercase tracking-widest">مؤشر جودة الإعمار</p>
        </div>
      </div>


      {/* Control Panel & Mission Grid */}
      <div className="px-5 lg:px-12 pb-32 space-y-8 relative z-10">
        
        {/* Search and Filters area */}
        <div className="flex flex-col lg:flex-row gap-4 mb-4">
          <div className="relative group flex-1">
            <Search className="absolute right-5 top-1/2 -translate-y-1/2 text-slate-300 group-focus-within:text-emerald-500 transition-colors" size={20} />
            <input 
              type="text" 
              placeholder="البحث في قاعدة البيانات الوطنية للمنشآت..." 
              className="w-full pr-14 pl-6 py-5 bg-white border border-slate-100 rounded-[2rem] text-sm font-bold focus:ring-8 focus:ring-emerald-500/5 focus:border-emerald-500 outline-none transition-all text-right shadow-[0_8px_30px_rgba(0,0,0,0.02)] placeholder:text-slate-300 placeholder:font-medium"
            />
          </div>
          <button 
            onClick={() => setShowFilters(!showFilters)}
            className={cn(
              "w-16 h-16 rounded-[2.2rem] flex items-center justify-center transition-all shadow-xl active:scale-95 border shrink-0 mx-auto lg:mx-0",
              showFilters ? "bg-emerald-600 text-white border-emerald-600" : "bg-white text-slate-400 border-slate-100"
            )}
          >
            <Filter size={24} strokeWidth={2.5} />
          </button>
        </div>

        <AnimatePresence>
          {showFilters && (
            <motion.div
              initial={{ opacity: 0, scale: 0.95, y: -10 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.95, y: -10 }}
              className="overflow-hidden bg-white/50 backdrop-blur-md p-2 rounded-[2.5rem] border border-slate-100 mb-6"
            >
              <div className="flex gap-2 overflow-x-auto p-2 no-scrollbar scroll-smooth">
                {[
                  { id: 'all', name: 'قاعدة البيانات العامة', color: '#64748b' },
                  { id: 'unassigned', name: 'بلاغات قيد التوجيه', color: '#94a3b8' },
                  ...INSTITUTIONS.map(inst => ({ id: inst.id, name: inst.fullName, color: inst.accentColor }))
                ].map(opt => (
                  <button
                    key={opt.id}
                    onClick={() => setSelectedInstitution(opt.id)}
                    className={cn(
                      "px-6 py-3.5 rounded-2xl text-[10px] font-black uppercase tracking-widest whitespace-nowrap transition-all border shrink-0",
                      selectedInstitution === opt.id
                        ? "bg-emerald-600 text-white border-emerald-600 shadow-[0_10px_30px_rgba(16,185,129,0.3)]"
                        : "bg-white text-slate-400 border-slate-100 hover:border-emerald-500/30"
                    )}
                  >
                    {opt.name}
                  </button>
                ))}
              </div>
            </motion.div>
          )}
        </AnimatePresence>

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
          {/* Map Column (Left/Primary) */}
          <div className="lg:col-span-12 xl:col-span-8 order-1 lg:order-1 sticky top-8">
            <div 
              className="h-[400px] lg:h-[700px] relative rounded-[4rem] overflow-hidden shadow-[0_40px_80px_-15px_rgba(0,0,0,0.15)] border-4 border-white group"
            >
              {/* Mission Control Labels */}
              <div className="absolute top-8 right-8 z-30 pointer-events-none">
                 <div className="bg-slate-950/80 backdrop-blur-md border border-white/20 p-4 rounded-2xl flex items-center gap-3 shadow-2xl">
                    <div className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse shadow-[0_0_10px_#10b981]" />
                    <span className="text-[10px] font-black text-white uppercase tracking-[0.3em]">LIVE_SATELLITE_FEED</span>
                 </div>
              </div>

              <div ref={mapRef} className={cn("w-full h-full", mapError && "hidden")} />
              
              {mapError && (
                <div className="absolute inset-0 z-40 bg-white">
                  {/* Fallback to Leaflet */}
                  <MapContainer 
                    center={[15.5007, 32.5599]} 
                    zoom={12} 
                    style={{ height: '100%', width: '100%' }}
                    zoomControl={false}
                  >
                    <TileLayer
                      attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
                      url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
                    />
                    {filteredIssues.map((issue) => (
                      <LeafletMarker 
                        key={issue.id} 
                        position={[issue.location.lat, issue.location.lng]}
                        eventHandlers={{
                          click: () => handleMarkerClick(issue),
                        }}
                      >
                        <Popup>
                          <div className="text-right font-black text-xs leading-tight">
                            {issue.trackingId}<br/>
                            {issue.type}
                          </div>
                        </Popup>
                      </LeafletMarker>
                    ))}
                  </MapContainer>
                </div>
              )}

              {loading && !mapError && (
                <MapSkeleton />
              )}

              {/* Marker Popup Info Card */}
              <AnimatePresence>
                {activeMarkerIssue && (
                  <motion.div 
                    initial={{ opacity: 0, scale: 0.85, y: 20, filter: 'blur(10px)' }}
                    animate={{ opacity: 1, scale: 1, y: 0, filter: 'blur(0px)' }}
                    exit={{ opacity: 0, scale: 0.85, y: 20, filter: 'blur(10px)' }}
                    transition={{ type: 'spring', damping: 25, stiffness: 300 }}
                    className="absolute bottom-6 left-6 right-6 p-5 glass-card shadow-[0_20px_50px_rgba(0,0,0,0.1)] z-30 border border-white/50"
                    onClick={(e) => e.stopPropagation()}
                  >
                    <div className="flex justify-between items-start mb-4">
                      <div className="flex items-center gap-4">
                        <div className={cn(
                          "w-12 h-12 rounded-2xl flex items-center justify-center shrink-0 border-2 shadow-sm",
                          activeMarkerIssue.severity === 3 
                            ? "bg-red-50 border-red-100 text-red-500" 
                            : "bg-emerald-50 border-emerald-100 text-emerald-500"
                        )}>
                          {getIssueIcon(activeMarkerIssue.type, 24)}
                        </div>
                        <div>
                          <div className="flex items-center gap-2 mb-1 text-right">
                            <h4 className="font-black text-slate-900 text-sm leading-tight font-display tracking-tight">
                              {activeMarkerIssue.type === 'road' ? 'بلاغ طرق' : 
                              activeMarkerIssue.type === 'water' ? 'بلاغ مياه' :
                              activeMarkerIssue.type === 'electricity' ? 'بلاغ كهرباء' : 'بلاغ نفايات'}
                            </h4>
                            <span className="px-1.5 py-0.5 bg-slate-100 text-slate-900 rounded-md text-[8px] font-black uppercase tracking-widest">
                              {activeMarkerIssue.trackingId}
                            </span>
                          </div>
                          <p className="text-[10px] text-emerald-600 font-black uppercase tracking-widest text-right">
                            {activeMarkerIssue.location.address || 'موقع قيد المراجعة'}
                          </p>
                        </div>
                      </div>
                      <button 
                        onClick={() => setActiveMarkerIssue(null)} 
                        className="p-2 transition-colors rounded-full hover:bg-slate-100 text-slate-400"
                      >
                        <X size={18} />
                      </button>
                    </div>

                    <p className="text-sm text-slate-600 line-clamp-2 mb-5 text-right font-medium leading-relaxed">
                      {activeMarkerIssue.description}
                    </p>

                    <button 
                      onClick={() => {
                        setSelectedIssue(activeMarkerIssue);
                        setActiveMarkerIssue(null);
                      }}
                      className="w-full py-4 bg-emerald-600 text-white rounded-2xl text-xs font-black uppercase tracking-[0.2em] shadow-xl hover:bg-emerald-700 transition-all active:scale-95 flex items-center justify-center gap-2"
                    >
                      <MapPin size={16} />
                      <span>عرض التفاصيل والتحليلات</span>
                    </button>
                  </motion.div>
                )}
              </AnimatePresence>
            </div>
          </div>

          {/* Activity/Content Column (Right) */}
          <div className="lg:col-span-12 xl:col-span-4 order-2 space-y-8 min-h-[500px]">
            {/* Tab Navigation Mini */}
            <div className="flex gap-2 overflow-x-auto no-scrollbar py-2 sticky top-0 bg-slate-50/80 backdrop-blur-md z-20 -mx-4 px-4 mb-4">
              {(['activity', 'archive', 'alerts', 'payments', 'compete'] as DashboardTab[]).map((tab) => (
                <button
                  key={tab}
                  onClick={() => setActiveTab(tab)}
                  className={cn(
                    "shrink-0 p-4 rounded-2xl text-[9px] font-black uppercase tracking-[0.2em] transition-all border flex items-center justify-center gap-2",
                    activeTab === tab 
                      ? "bg-emerald-600 border-emerald-600 text-white shadow-lg" 
                      : "bg-white border-slate-100 text-slate-400 hover:border-emerald-500"
                  )}
                  title={tab === 'activity' ? 'الميدان' : tab === 'archive' ? 'السجل الوطني' : tab === 'alerts' ? 'التحذيرات' : tab === 'payments' ? 'المدفوعات' : 'المنافسة'}
                >
                  {tab === 'activity' && <Grid size={12} />}
                  {tab === 'archive' && <History size={12} />}
                  {tab === 'alerts' && <Bell size={12} />}
                  {tab === 'payments' && <Wallet size={12} />}
                  {tab === 'compete' && <Trophy size={12} />}
                </button>
              ))}
            </div>

            <AnimatePresence mode="wait">
              {activeTab === 'activity' && (
                <motion.div 
                  key="activity"
                  initial={{ opacity: 0, x: 20 }}
                  animate={{ opacity: 1, x: 0 }}
                  exit={{ opacity: 0, x: -20 }}
                  className="space-y-6"
                >
                  <div className="flex justify-between items-center px-2">
                    <h3 className="text-[11px] font-black text-slate-400 uppercase tracking-[0.3em] text-right">البلاغات الأخيرة</h3>
                    <div className="flex items-center gap-1">
                       <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 shadow-[0_0_8px_#10b981]" />
                       <span className="text-[9px] font-black text-slate-400 uppercase tracking-widest">REALTIME</span>
                    </div>
                  </div>

                  <div className="space-y-4 max-h-[1000px] overflow-y-auto no-scrollbar pr-1 -mr-1">
                    {filteredIssues.map((issue, idx) => {
                      return (
                        <motion.div 
                          key={issue.id}
                          initial={{ opacity: 0, x: 15 }}
                          animate={{ opacity: 1, x: 0 }}
                          transition={{ delay: idx * 0.05 }}
                          onClick={() => setSelectedIssue(issue)}
                          className="group cursor-pointer bg-white border border-slate-100 p-5 rounded-[2rem] hover:border-emerald-500 shadow-sm hover:shadow-xl transition-all duration-500 active:scale-[0.98]"
                        >
                          <div className="flex gap-4 items-start flex-row-reverse">
                            <div className={cn(
                              "w-12 h-12 rounded-2xl flex items-center justify-center shrink-0 border-2 transition-all duration-500 group-hover:rotate-6",
                              issue.severity === 3 ? "bg-rose-50 border-rose-100 text-rose-500" : 
                              issue.severity === 2 ? "bg-amber-50 border-amber-100 text-amber-500" : "bg-emerald-50 border-emerald-100 text-emerald-500"
                            )}>
                              {getIssueIcon(issue.type, 20)}
                            </div>
                            
                            <div className="flex-1 min-w-0 text-right">
                              <div className="flex justify-between items-center mb-1 flex-row-reverse">
                                <span className="font-mono text-[8px] font-black px-1.5 py-0.5 bg-slate-900 text-white rounded-md">
                                  {issue.trackingId}
                                </span>
                                <span className="text-[9px] font-black text-slate-300 uppercase tracking-widest">
                                  {issue.createdAt ? formatTimeAgo(typeof issue.createdAt === 'number' ? issue.createdAt : (issue.createdAt as any).seconds * 1000) : 'الآن'}
                                </span>
                              </div>
                              <h4 className="text-sm font-black text-slate-950 mb-1 truncate">
                                {issue.type === 'road' ? 'بلاغ طرق' : 
                                 issue.type === 'water' ? 'بلاغ مياه' :
                                 issue.type === 'electricity' ? 'بلاغ كهرباء' : 'بلاغ إصحاح'}
                              </h4>
                              <p className="text-[11px] text-slate-500 line-clamp-1">
                                {issue.description || issue.location.address}
                              </p>
                              
                              <div className="flex justify-between items-center mt-3 pt-3 border-t border-slate-50 flex-row-reverse">
                                 <div className={cn(
                                   "px-2 py-0.5 rounded-full text-[7px] font-black uppercase tracking-widest border",
                                   issue.status === 'pending' ? "bg-amber-50 text-amber-600 border-amber-100" : "bg-emerald-50 text-emerald-600 border-emerald-100"
                                 )}>
                                   {issue.status === 'pending' ? 'قيد المراجعة' : 'تحت المعالجة'}
                                 </div>
                                 <div className="flex items-center gap-1 text-[9px] font-bold text-slate-400">
                                   <MapPin size={10} className="text-emerald-500" />
                                   <span className="truncate max-w-[80px]">{issue.location.address?.split(',')[0]}</span>
                                 </div>
                              </div>
                            </div>
                          </div>
                        </motion.div>
                      );
                    })}

                    {filteredIssues.length === 0 && !loading && (
                      <div className="text-center py-20 lg:py-40 bento-inner border-dashed border-2 border-slate-100">
                         <p className="text-[9px] text-slate-400 font-black uppercase tracking-[0.3em]">قاعدة البيانات فارغة</p>
                      </div>
                    )}
                  </div>
                </motion.div>
              )}

              {activeTab === 'alerts' && <AlertsList />}
              {activeTab === 'payments' && <UtilityPayments />}
              {activeTab === 'compete' && <RegionalCompetition />}
              {activeTab === 'archive' && (
                <div className="text-center py-20 bg-slate-50/50 rounded-[3rem] border-2 border-dashed border-slate-200">
                   <History size={32} className="mx-auto text-slate-300 mb-4" />
                   <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest">الأرشفة الوطنية قيد التهيئة</p>
                </div>
              )}
            </AnimatePresence>
          </div>
        </div>

        {/* National Partners Showcase - Premium Scrolling List */}
        <div className="pt-16 pb-8 mt-12 bg-white/30 backdrop-blur-md rounded-[4rem] p-10 border border-white">
          <div className="flex flex-col items-center mb-10 space-y-2">
            <div className="w-12 h-1 px-4 bg-emerald-500 mb-4 rounded-full opacity-30" />
            <h3 className="text-[12px] font-black text-emerald-900 uppercase tracking-[0.4em] text-center">شركاء الإعمار الوطنيين الاستراتيجيين</h3>
            <p className="text-[10px] text-slate-400 font-bold uppercase tracking-widest italic">المؤسسات والوزارات والجهات المكلفة بالحلول</p>
          </div>
          
          <div className="flex gap-8 overflow-x-auto pb-6 no-scrollbar scroll-smooth snap-x">
            {INSTITUTIONS.map((inst) => (
              <div 
                key={inst.id}
                className="shrink-0 flex flex-col items-center gap-4 group cursor-pointer snap-center"
                title={inst.fullName}
              >
                <div className="w-24 h-24 rounded-[2.5rem] bg-white border border-slate-100 flex items-center justify-center overflow-hidden transition-all duration-500 group-hover:border-emerald-500 group-hover:scale-110 shadow-[0_10px_30px_rgba(0,0,0,0.02)] group-hover:shadow-emerald-500/10">
                  {inst.logo ? (
                    <img 
                      src={inst.logo} 
                      alt={inst.name} 
                      className="w-full h-full object-cover p-2 transition-transform group-hover:scale-110 group-hover:rotate-3" 
                      referrerPolicy="no-referrer"
                    />
                  ) : (
                    <Building className="text-slate-200" size={32} />
                  )}
                </div>
                <div className="text-center">
                  <span className="text-[9px] font-black text-slate-900 uppercase tracking-widest block mb-0.5 group-hover:text-emerald-600 transition-colors">{inst.name}</span>
                  <span className={cn(
                    "text-[7px] font-black uppercase tracking-[0.2em] px-2 py-0.5 rounded border",
                    inst.type !== 'partner' ? "bg-emerald-50 text-emerald-600 border-emerald-100" : "bg-blue-50 text-blue-600 border-blue-100"
                  )}>{inst.type !== 'partner' ? 'حكومي' : 'خاص'}</span>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      <AnimatePresence>
        {selectedIssue && (
          <IssueDetail 
            issue={selectedIssue} 
            onClose={() => setSelectedIssue(null)} 
          />
        )}
      </AnimatePresence>
    </div>
  );
}

function MapSkeleton() {
  return (
    <div className="absolute inset-0 bg-slate-50 flex items-center justify-center overflow-hidden">
      <div className="absolute inset-0 opacity-20" style={{ backgroundImage: 'radial-gradient(#cbd5e1 1px, transparent 1px)', backgroundSize: '32px 32px' }} />
      <div className="absolute inset-0 bg-gradient-to-tr from-transparent via-white/40 to-transparent animate-[shimmer_2s_infinite]" />
      
      {/* Mock Map Lines */}
      <svg className="absolute inset-0 w-full h-full opacity-[0.05]" xmlns="http://www.w3.org/2000/svg">
        <path d="M0 100 Q 250 50 500 150 T 1000 100" fill="none" stroke="currentColor" strokeWidth="8" />
        <path d="M-100 200 L 1200 400" fill="none" stroke="currentColor" strokeWidth="4" />
        <path d="M300 0 L 300 600" fill="none" stroke="currentColor" strokeWidth="12" />
      </svg>

      <div className="relative flex flex-col items-center gap-6">
        <div className="relative">
          <div className="w-20 h-20 rounded-full bg-white shadow-xl flex items-center justify-center animate-pulse">
            <div className="w-12 h-12 rounded-full bg-emerald-50 text-emerald-300 flex items-center justify-center">
              <MapIcon size={28} />
            </div>
          </div>
          <motion.div 
            animate={{ scale: [1, 1.5, 1], opacity: [0.1, 0.3, 0.1] }}
            transition={{ duration: 2, repeat: Infinity }}
            className="absolute -inset-4 bg-emerald-400 rounded-full -z-10"
          />
        </div>
        <p className="text-[10px] font-black text-slate-400 uppercase tracking-[0.3em] animate-pulse">جاري تحميل الخريطة الميدانية...</p>
      </div>
    </div>
  );
}

