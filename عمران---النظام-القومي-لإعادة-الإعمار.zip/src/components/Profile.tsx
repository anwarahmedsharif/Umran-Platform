import React, { useState, useEffect } from 'react';
import { motion } from 'motion/react';
import { 
  User as UserIcon, 
  Trophy, 
  History, 
  Settings, 
  MapPin, 
  CheckCircle, 
  TrendingUp, 
  Heart,
  Award,
  Users,
  ArrowRight,
  ShieldCheck,
  Star,
  Droplets,
  Zap,
  Trash2,
  HelpCircle
} from 'lucide-react';
import { collection, query, where, onSnapshot, doc, getDoc } from 'firebase/firestore';
import { db, auth } from '../lib/firebase';
import { Issue, User as UserProfile, Campaign, Participation } from '../types';
import { cn, formatTimeAgo } from '../lib/utils';

export default function Profile() {
  const [userProfile, setUserProfile] = useState<UserProfile | null>(null);
  const [userIssues, setUserIssues] = useState<Issue[]>([]);
  const [loading, setLoading] = useState(true);
  const [participations, setParticipations] = useState<Participation[]>([]);

  const getIssueIcon = (type: string, size = 24) => {
    switch (type) {
      case 'road': return <MapPin size={size} />;
      case 'water': return <Droplets size={size} />;
      case 'electricity': return <Zap size={size} />;
      case 'waste': return <Trash2 size={size} />;
      default: return <HelpCircle size={size} />;
    }
  };

  useEffect(() => {
    if (!auth.currentUser) return;

    // Fetch Profile
    const fetchProfile = async () => {
      const snap = await getDoc(doc(db, 'users', auth.currentUser!.uid));
      if (snap.exists()) {
        setUserProfile(snap.data() as UserProfile);
      } else {
        // Fallback for demo
        setUserProfile({
          uid: auth.currentUser!.uid,
          displayName: auth.currentUser!.isAnonymous ? 'مواطن مجهول' : 'مستخدم عمران',
          points: 1250, // Mock points
          role: 'citizen',
          isAnonymous: auth.currentUser!.isAnonymous,
          regionId: 'khartoum'
        });
      }
    };

    fetchProfile();

    // Fetch User Reports
    const qIssues = query(
      collection(db, 'issues'), 
      where('reporterId', '==', auth.currentUser.uid)
    );
    const unsubIssues = onSnapshot(qIssues, (snapshot) => {
      const fetched = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() })) as Issue[];
      setUserIssues(fetched.sort((a, b) => b.createdAt - a.createdAt));
      setLoading(false);
    }, (err) => {
      console.error(err);
      setLoading(false);
    });

    // Real Participation Fetching
    const qParts = query(collection(db, 'users', auth.currentUser.uid, 'participations'));
    const unsubParts = onSnapshot(qParts, (snapshot) => {
      const fetched = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() })) as Participation[];
      setParticipations(fetched.sort((a, b) => {
        const timeA = typeof a.createdAt === 'number' ? a.createdAt : (a.createdAt as any)?.seconds * 1000 || 0;
        const timeB = typeof b.createdAt === 'number' ? b.createdAt : (b.createdAt as any)?.seconds * 1000 || 0;
        return timeB - timeA;
      }));
    });

    return () => {
      unsubIssues();
      unsubParts();
    };
  }, []);

  if (loading) {
    return (
      <div className="h-full flex items-center justify-center p-6 bg-white shrink-0 shadow-sm border border-slate-50">
        <div className="flex flex-col items-center gap-4">
          <div className="w-12 h-12 border-4 border-emerald-500 border-t-transparent rounded-full animate-spin" />
          <p className="text-sm font-black text-slate-400 uppercase tracking-widest">جاري تحميل ملفك الوطني...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="h-full overflow-y-auto p-6 space-y-8 bg-slate-50/30" dir="rtl">
      {/* Profile Header Card */}
      <section className="bg-emerald-600 rounded-[40px] p-8 text-white relative overflow-hidden shadow-2xl">
        <div className="absolute top-0 right-0 w-64 h-full opacity-10 pointer-events-none sudan-texture" />
        <div className="absolute -bottom-10 -left-10 w-40 h-40 bg-white/10 blur-[80px] rounded-full" />
        
        <div className="relative z-10 flex flex-col md:flex-row items-center gap-8 md:text-right">
          <div className="relative group">
            <div className="w-32 h-32 rounded-[40px] bg-white flex items-center justify-center text-emerald-600 relative z-10 border-4 border-white/10 shadow-2xl">
              <UserIcon size={64} strokeWidth={1.5} />
            </div>
            <div className="absolute -bottom-2 -right-2 w-10 h-10 bg-amber-400 rounded-2xl flex items-center justify-center text-white border-4 border-emerald-600 z-20 shadow-lg">
              <Award size={20} fill="currentColor" />
            </div>
          </div>

          <div className="flex-1 space-y-2">
            <div className="flex items-center gap-3 md:justify-start justify-center">
              <h2 className="text-3xl font-black font-display tracking-tight text-white">{userProfile?.displayName}</h2>
              <span className="px-3 py-1 bg-white/20 text-white border border-white/30 rounded-full text-[10px] font-black uppercase tracking-widest leading-none">
                {userProfile?.role === 'official' ? 'مسؤول حكومي' : 'مواطن فاعل'}
              </span>
            </div>
            <div className="flex items-center gap-4 md:justify-start justify-center text-emerald-50">
              <div className="flex items-center gap-1.5">
                <MapPin size={14} className="text-white" />
                <span className="text-xs font-bold leading-none">الخرطوم، السودان</span>
              </div>
              <div className="w-1 h-1 bg-white/20 rounded-full" />
              <div className="flex items-center gap-1.5">
                <ShieldCheck size={14} className="text-white" />
                <span className="text-xs font-bold leading-none">حساب موثق</span>
              </div>
            </div>
          </div>

          <div className="flex flex-col items-center gap-2 bg-white/10 border border-white/20 p-6 rounded-[32px] min-w-[160px] backdrop-blur-md">
             <p className="text-[10px] font-black text-emerald-100 uppercase tracking-[0.2em] leading-none mb-1">نقاط العمران</p>
             <div className="flex items-center gap-2">
               <Trophy size={20} className="text-amber-400" />
               <span className="text-3xl font-black font-mono text-white">{userProfile?.points.toLocaleString()}</span>
             </div>
             <p className="text-[9px] text-white/40 font-bold">باقي ٥٠٠ نقطة للمستوى التالي</p>
          </div>
        </div>
      </section>

      {/* Stats Grid */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        {[
          { label: 'البلاغات المرسلة', value: userIssues.length, icon: <History className="text-blue-500" />, color: 'blue' },
          { label: 'المبادرات النشطة', value: participations.length, icon: <Users className="text-emerald-500" />, color: 'emerald' },
          { label: 'بلاغات معالجة', value: userIssues.filter(i => i.status === 'resolved').length, icon: <CheckCircle className="text-amber-500" />, color: 'amber' },
          { label: 'ترتيبك الوطني', value: '#١٢٤', icon: <TrendingUp className="text-purple-500" />, color: 'purple' },
        ].map((stat, i) => (
          <div key={i} className="bg-white border border-slate-100 p-6 rounded-[32px] space-y-3 shadow-sm">
            <div className={cn("w-10 h-10 rounded-2xl flex items-center justify-center bg-slate-50")}>
              {stat.icon}
            </div>
            <div>
              <p className="text-[9px] font-black text-slate-400 uppercase tracking-widest mb-1">{stat.label}</p>
              <p className="text-xl font-black text-slate-900 leading-none">{stat.value}</p>
            </div>
          </div>
        ))}
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
        {/* Recent Reports */}
        <section className="space-y-6">
          <div className="flex justify-between items-center px-2">
            <h3 className="text-xl font-black text-slate-900 font-display">بلاغاتي الميدانية</h3>
            <span className="text-[10px] font-black text-slate-300 uppercase tracking-widest">آخر {userIssues.length} بلاغات</span>
          </div>
          
          <div className="space-y-4">
            {userIssues.map((issue, idx) => (
              <motion.div 
                key={issue.id}
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: idx * 0.05 }}
                className="bg-white border border-slate-100 p-5 rounded-[28px] flex items-center gap-4 hover:border-emerald-500 transition-all group shadow-sm"
              >
                <div className={cn(
                  "w-14 h-14 rounded-3xl flex items-center justify-center shrink-0 border transition-all group-hover:scale-110",
                  issue.severity === 3 ? "bg-red-50 border-red-100 text-red-500" : "bg-emerald-50 border-emerald-100 text-emerald-500"
                )}>
                  {getIssueIcon(issue.type, 24)}
                </div>
                <div className="flex-1 min-w-0 text-right space-y-1">
                  <div className="flex justify-between items-baseline mb-1">
                    <span className="px-1.5 py-0.5 bg-slate-100 text-slate-900 rounded-md text-[8px] font-black uppercase tracking-widest whitespace-nowrap">
                      {issue.trackingId}
                    </span>
                    <span className="text-[9px] text-slate-400 font-black uppercase tracking-widest">
                     {formatTimeAgo(typeof issue.createdAt === 'number' ? issue.createdAt : (issue.createdAt as any).seconds * 1000)}
                    </span>
                  </div>
                  <h4 className="text-sm font-black text-slate-900 tracking-tight leading-tight line-clamp-1">{issue.description}</h4>
                  <div className="flex gap-2">
                    <span className={cn(
                      "text-[8px] font-black px-2 py-0.5 rounded-full uppercase tracking-widest",
                      issue.status === 'pending' ? "bg-amber-50 text-amber-600 border border-amber-100" : "bg-emerald-50 text-emerald-600 border border-emerald-100"
                    )}>
                      {issue.status === 'pending' ? 'جاري المراجعة' : 'تحت المعالجة'}
                    </span>
                  </div>
                </div>
              </motion.div>
            ))}
            
            {userIssues.length === 0 && (
              <div className="py-12 bento-inner border-dashed border-2 border-slate-100 text-center space-y-4">
                 <div className="w-16 h-16 bg-slate-50 rounded-full flex items-center justify-center mx-auto text-slate-300">
                    <History size={32} />
                 </div>
                 <p className="text-xs text-slate-400 font-black uppercase tracking-widest">لم تقم بإضافة أي بلاغات بعد</p>
              </div>
            )}
          </div>
        </section>

        {/* Campaign Participation */}
        <section className="space-y-6">
          <div className="flex justify-between items-center px-2">
            <h3 className="text-xl font-black text-slate-900 font-display">المشاركة في المبادرات</h3>
            <div className="flex items-center gap-1.5 text-emerald-600">
              <Heart size={14} fill="currentColor" />
              <span className="text-[10px] font-black uppercase tracking-widest">متطوع نشط</span>
            </div>
          </div>

          <div className="space-y-4">
            {participations.map((part, idx) => (
              <div key={part.id} className="bg-white border border-slate-100 rounded-[32px] overflow-hidden shadow-sm hover:shadow-md transition-shadow group">
                <div className="h-28 bg-slate-200 relative overflow-hidden">
                  <img src={part.campaignImage || `https://picsum.photos/seed/${part.campaignId}/400/200`} className="w-full h-full object-cover transition-transform group-hover:scale-110 duration-700" alt={part.campaignTitle} />
                  <div className="absolute inset-0 bg-gradient-to-t from-emerald-600/80 to-transparent" />
                  <div className="absolute bottom-4 right-4 left-4 flex justify-between items-end">
                    <div className="text-right">
                       <h4 className="text-white font-black text-sm tracking-tight leading-tight">{part.campaignTitle}</h4>
                       <p className="text-[9px] text-emerald-100 font-bold uppercase tracking-widest mt-1">
                         {part.type === 'join' ? 'مشاركة ميدانية' : `رعاية مالية (${part.amount?.toLocaleString()} ج.س)`}
                       </p>
                    </div>
                  </div>
                </div>
                <div className="p-5 space-y-4">
                  <div className="flex justify-between items-center flex-row-reverse border-t border-slate-50 pt-4">
                    <div className="flex items-center gap-2">
                      <Star size={14} className="text-amber-400" fill="currentColor" />
                      <span className="text-xs font-black text-slate-800">+{part.pointsEarned} نقطة</span>
                    </div>
                    <div className="text-[9px] text-slate-400 font-black uppercase tracking-widest">
                      {formatTimeAgo(typeof part.createdAt === 'number' ? part.createdAt : (part.createdAt as any).seconds * 1000)}
                    </div>
                  </div>
                </div>
              </div>
            ))}

            {participations.length === 0 && (
              <button className="w-full py-12 border-2 border-dashed border-slate-100 rounded-[32px] text-[10px] font-black text-slate-400 uppercase tracking-widest hover:border-emerald-500 hover:text-emerald-600 transition-all flex flex-col items-center justify-center gap-4">
                 <div className="w-12 h-12 bg-slate-50 rounded-full flex items-center justify-center text-slate-300">
                    <Trophy size={24} />
                 </div>
                 <span>استكشف مبادرات جديدة في ولايتك</span>
              </button>
            )}
          </div>
        </section>
      </div>

      {/* Achievements / Badges */}
      <section className="space-y-6 pt-4">
        <div className="flex justify-between items-center px-2">
           <h3 className="text-xl font-black text-slate-900 font-display">الأوسمة والجوائز</h3>
           <Award size={20} className="text-amber-400" />
        </div>
        <div className="flex gap-4 overflow-x-auto no-scrollbar pb-4">
          {[
            { label: 'المواطن الرقمي', icon: <ShieldCheck />, desc: 'تجاوز ١٠ بلاغات', color: 'bg-blue-50 text-blue-600' },
            { label: 'راعي السلام', icon: <Heart />, desc: 'مساهمة مالية أولى', color: 'bg-pink-50 text-pink-600' },
            { label: 'إعمار الطرق', icon: <MapPin />, desc: 'إصلاح طريق حي', color: 'bg-amber-50 text-amber-600' },
            { label: 'الخبير الميداني', icon: <Users />, desc: 'تطوع في ٥ مبادرات', color: 'bg-emerald-50 text-emerald-600' },
          ].map((badge, i) => (
            <div key={i} className="shrink-0 bg-white border border-slate-100 p-6 rounded-[32px] w-48 text-center space-y-4 shadow-sm hover:shadow-md transition-shadow">
               <div className={cn("w-16 h-16 mx-auto rounded-3xl flex items-center justify-center", badge.color)}>
                  {React.cloneElement(badge.icon as any, { size: 32 })}
               </div>
               <div>
                  <p className="text-sm font-black text-slate-900 tracking-tight">{badge.label}</p>
                  <p className="text-[9px] text-slate-400 font-bold uppercase tracking-widest mt-1">{badge.desc}</p>
               </div>
            </div>
          ))}
        </div>
      </section>

      {/* Footer Settings Link */}
      <footer className="pt-8 border-t border-slate-100 flex justify-center">
         <button className="flex items-center gap-3 text-slate-400 hover:text-slate-600 transition-colors">
            <Settings size={16} />
            <span className="text-[10px] font-black uppercase tracking-widest">إعدادات الحساب والتوثيق</span>
         </button>
      </footer>
    </div>
  );
}
