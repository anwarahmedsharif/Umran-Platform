import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Building, Shield, ChevronRight, Loader2, ArrowLeft, Mail, Lock } from 'lucide-react';
import { signInWithEmailAndPassword } from 'firebase/auth';
import { auth } from '../lib/firebase';
import { INSTITUTIONS } from '../constants';
import { cn } from '../lib/utils';

export default function InstitutionLogin({ onClose }: { onClose: () => void }) {
  const [step, setStep] = useState(1);
  const [selectedInst, setSelectedInst] = useState<any>(null);
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setError(null);
    try {
      await signInWithEmailAndPassword(auth, email, password);
      onClose();
    } catch (err: any) {
      setError(err.message || 'فشل تسجيل الدخول. يرجى مراجعة البيانات.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="p-8 h-full flex flex-col bg-slate-950 text-white relative overflow-hidden" dir="rtl">
       <div className="absolute inset-0 opacity-[0.05] pointer-events-none sudan-texture scale-150 rotate-12" />
       
       <button onClick={onClose} className="absolute top-8 left-8 p-3 bg-white/5 hover:bg-white/10 rounded-2xl transition-all z-10 border border-white/10">
          <ArrowLeft size={20} />
       </button>

       <div className="mb-12 relative z-10">
          <div className="w-16 h-16 bg-emerald-500 rounded-3xl flex items-center justify-center text-white mb-6 shadow-2xl rotate-3">
             <Shield size={32} />
          </div>
          <h2 className="text-4xl font-black tracking-tighter mb-2">بوابة المؤسسات السيادية</h2>
          <p className="text-slate-400 font-medium">تسجيل الدخول للوصول إلى مركز القيادة والتحكم</p>
       </div>

       <div className="flex-1 overflow-hidden relative z-10">
          <AnimatePresence mode="wait">
            {step === 1 ? (
              <motion.div
                key="step1"
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: -20 }}
                className="space-y-4 h-full overflow-y-auto no-scrollbar pb-10"
              >
                <p className="text-[10px] font-black text-emerald-500 uppercase tracking-[0.3em] mb-6">اختر المؤسسة المعنية</p>
                <div className="grid grid-cols-1 gap-3">
                  {INSTITUTIONS.map((inst) => (
                    <button
                      key={inst.id}
                      onClick={() => {
                        setSelectedInst(inst);
                        setStep(2);
                      }}
                      className="group flex items-center justify-between p-5 bg-white/5 border border-white/10 rounded-[2rem] hover:bg-emerald-600 hover:border-emerald-600 transition-all duration-500 text-right active:scale-[0.98]"
                    >
                      <div className="flex items-center gap-5">
                        <div className="w-14 h-14 bg-white rounded-2xl flex items-center justify-center overflow-hidden transition-transform group-hover:scale-110">
                           {inst.logo ? (
                             <img src={inst.logo} alt={inst.name} className="w-full h-full object-cover" referrerPolicy="no-referrer" />
                           ) : (
                             <Building className="text-slate-200" size={24} />
                           )}
                        </div>
                        <div>
                          <p className="text-xs font-black group-hover:text-white transition-colors">{inst.fullName}</p>
                          <p className="text-[10px] text-slate-500 group-hover:text-emerald-100 uppercase tracking-widest">{inst.id}</p>
                        </div>
                      </div>
                      <ChevronRight size={20} className="text-slate-600 group-hover:text-white" />
                    </button>
                  ))}
                </div>
              </motion.div>
            ) : (
              <motion.div
                key="step2"
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: -20 }}
                className="space-y-8"
              >
                <button 
                  onClick={() => setStep(1)}
                  className="flex items-center gap-2 text-emerald-500 text-[10px] font-black uppercase tracking-widest hover:text-emerald-400 transition-colors"
                >
                  <ArrowLeft size={14} />
                  العودة لقائمة المؤسسات
                </button>

                <div className="flex items-center gap-5 p-6 bg-emerald-600/20 border border-emerald-500/20 rounded-[2.5rem]">
                   <div className="w-16 h-16 bg-white rounded-2xl flex items-center justify-center overflow-hidden">
                      <img src={selectedInst.logo} alt={selectedInst.name} className="w-full h-full object-cover" referrerPolicy="no-referrer" />
                   </div>
                   <div>
                      <p className="text-sm font-black text-white">{selectedInst.fullName}</p>
                      <p className="text-[10px] text-emerald-500 font-black uppercase tracking-widest">مصادقة مشفرة</p>
                   </div>
                </div>

                <form onSubmit={handleLogin} className="space-y-6">
                   <div className="space-y-4">
                      <div className="relative group">
                         <Mail className="absolute right-5 top-1/2 -translate-y-1/2 text-slate-500 group-focus-within:text-emerald-500 transition-colors" size={20} />
                         <input 
                           type="email" 
                           required
                           value={email}
                           onChange={(e) => setEmail(e.target.value)}
                           placeholder="البريد الإلكتروني المعتمد" 
                           className="w-full pr-14 pl-6 py-5 bg-white/5 border border-white/10 rounded-[2rem] text-sm font-bold focus:ring-8 focus:ring-emerald-500/10 focus:border-emerald-500 outline-none transition-all placeholder:text-slate-600 text-right"
                         />
                      </div>
                      <div className="relative group">
                         <Lock className="absolute right-5 top-1/2 -translate-y-1/2 text-slate-500 group-focus-within:text-emerald-500 transition-colors" size={20} />
                         <input 
                           type="password" 
                           required
                           value={password}
                           onChange={(e) => setPassword(e.target.value)}
                           placeholder="رمز الدخول السيادي" 
                           className="w-full pr-14 pl-6 py-5 bg-white/5 border border-white/10 rounded-[2rem] text-sm font-bold focus:ring-8 focus:ring-emerald-500/10 focus:border-emerald-500 outline-none transition-all placeholder:text-slate-600 text-right"
                         />
                      </div>
                   </div>

                   {error && (
                     <div className="p-4 bg-rose-500/10 border border-rose-500/20 rounded-2xl text-[10px] font-black text-rose-400 uppercase tracking-widest text-center">
                        {error}
                     </div>
                   )}

                   <button 
                     type="submit" 
                     disabled={loading}
                     className="w-full py-6 bg-emerald-600 text-white font-black rounded-[2.5rem] flex items-center justify-center gap-4 shadow-2xl transition-all active:scale-[0.98] disabled:opacity-50 text-[12px] uppercase tracking-[0.4em] hover:bg-emerald-500"
                   >
                     {loading ? <Loader2 className="animate-spin" size={20} /> : 'تسجيل دخول آمن'}
                   </button>
                </form>
              </motion.div>
            )}
          </AnimatePresence>
       </div>

       <div className="pt-8 border-t border-white/5 flex justify-between items-center relative z-10">
          <div className="text-right">
             <p className="text-[8px] font-black text-slate-500 uppercase tracking-[0.2em] mb-1">ENCRYPTION PROTOCOL</p>
             <p className="text-[10px] font-black text-emerald-500/60 uppercase tracking-widest">AES-256 BIT / SH-01</p>
          </div>
          <div className="w-12 h-1 px-4 bg-emerald-500 mb-4 rounded-full opacity-20" />
       </div>
    </div>
  );
}
