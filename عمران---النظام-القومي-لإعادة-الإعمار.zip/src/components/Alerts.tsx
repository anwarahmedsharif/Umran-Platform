import React from 'react';
import { motion } from 'motion/react';
import { AlertTriangle, Info, Bell, Shield, Wind, CloudRain, Zap, CheckCheck } from 'lucide-react';
import { cn, formatTimeAgo } from '../lib/utils';
import { useNotifications } from '../contexts/NotificationContext';

const ALERT_ICONS: Record<string, any> = {
  weather: CloudRain,
  infrastructure: Zap,
  security: Shield,
  health: Bell,
  campaigns: Bell
};

export default function AlertsList() {
  const { alerts, markAllAsRead, unreadCount } = useNotifications();

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between mb-4">
        <h3 className="font-black text-slate-800 text-lg font-display tracking-normal">تنبيهات الجهات الرسمية</h3>
        <div className="flex items-center gap-2">
          {unreadCount > 0 && (
            <button 
              onClick={markAllAsRead}
              className="px-3 py-1.5 bg-emerald-50 text-emerald-600 rounded-lg text-[9px] font-black uppercase tracking-widest flex items-center gap-1.5 hover:bg-emerald-100 transition-colors"
            >
              <CheckCheck size={12} />
              قراءة الكل
            </button>
          )}
          <span className="text-[10px] font-black text-red-500 bg-red-50 px-2 py-1 rounded-md uppercase tracking-widest border border-red-100 flex items-center gap-1 animate-pulse">
             <AlertTriangle size={12} />
             مباشر
          </span>
        </div>
      </div>

      <div className="space-y-3">
        {alerts.map((alert, index) => {
          const Icon = ALERT_ICONS[alert.type] || Info;
          const isHigh = alert.severity === 'high' || alert.severity === 'critical';
          
          return (
            <motion.div
              key={alert.id}
              initial={{ x: 20, opacity: 0 }}
              animate={{ x: 0, opacity: 1 }}
              transition={{ delay: index * 0.1 }}
              className={cn(
                "p-4 rounded-[24px] border transition-all relative overflow-hidden",
                isHigh 
                  ? "bg-red-50 border-red-100" 
                  : "bg-amber-50 border-amber-100",
                !alert.read && "ring-2 ring-emerald-500/20"
              )}
            >
              {!alert.read && (
                <div className="absolute top-2 right-2 w-2 h-2 bg-emerald-500 rounded-full" />
              )}
              <div className="flex items-start gap-4">
                <div className={cn(
                  "p-3 rounded-2xl shrink-0",
                  isHigh ? "bg-red-500 text-white" : "bg-amber-500 text-white"
                )}>
                  <Icon size={20} />
                </div>
                
                <div className="flex-1 text-right">
                  <div className="flex justify-between items-center mb-1">
                    <span className="text-[9px] font-black text-slate-400 font-mono">
                      {new Date(alert.timestamp).toLocaleTimeString('ar-SD', { hour: '2-digit', minute: '2-digit' })}
                    </span>
                    <h5 className={cn(
                      "text-xs font-black uppercase tracking-widest",
                      isHigh ? "text-red-700" : "text-amber-700"
                    )}>
                      المكتب الإعلامي | عمران
                    </h5>
                  </div>
                  <h4 className="text-sm font-black text-slate-900 mb-1">{alert.title}</h4>
                  <p className="text-xs text-slate-600 leading-relaxed">{alert.message}</p>
                </div>
              </div>
            </motion.div>
          );
        })}
        {alerts.length === 0 && (
          <div className="text-center py-12 text-slate-400 text-xs italic">لا توجد تنبيهات حالياً.</div>
        )}
      </div>
    </div>
  );
}
