import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Users, 
  TrendingUp, 
  MapPin, 
  CheckCircle2, 
  Clock, 
  Plus,
  ArrowUpRight,
  Loader2,
  Trophy,
  Coins,
  HandCoins,
  Heart,
  Crown,
  ShieldCheck,
  Building2,
  ExternalLink
} from 'lucide-react';
import { 
  collection, 
  query, 
  onSnapshot, 
  updateDoc, 
  doc, 
  increment, 
  setDoc, 
  serverTimestamp, 
  writeBatch 
} from 'firebase/firestore';
import { db, auth } from '../lib/firebase';
import { cn, handleFirestoreError } from '../lib/utils';
import { Campaign } from '../types';
import { REGIONS, INSTITUTIONS } from '../constants';

export default function Campaigns() {
  const [campaigns, setCampaigns] = useState<Campaign[]>([]);
  const [loading, setLoading] = useState(true);
  const [selectedRegion, setSelectedRegion] = useState<string>('all');
  const [sortBy, setSortBy] = useState<'progress' | 'participants' | 'reward'>('progress');

  useEffect(() => {
    const q = query(collection(db, 'campaigns'));
    const unsubscribe = onSnapshot(q, (snapshot) => {
      const fetched = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() })) as Campaign[];
      setCampaigns(fetched);
      setLoading(false);
    }, (error) => {
      console.error("Error fetching campaigns:", error);
      setLoading(false);
    });
    return () => unsubscribe();
  }, []);

  const handleJoin = async (id: string, points: number) => {
    if (!auth.currentUser) return alert("سجل دخولك أولاً للمشاركة");
    try {
      const batch = writeBatch(db);
      const uid = auth.currentUser.uid;
      
      const campaign = campaigns.find(c => c.id === id);
      const campaignData = {
        userId: uid,
        campaignId: id,
        campaignTitle: campaign?.title || 'مهمة عمران',
        campaignImage: campaign?.beforeImageUrl || '',
        pointsEarned: points,
        createdAt: serverTimestamp()
      };
      
      const campaignPartRef = doc(db, 'campaigns', id, 'participations', uid);
      batch.set(campaignPartRef, {
        ...campaignData,
        type: 'join'
      });

      const userPartRef = doc(db, 'users', uid, 'participations', id);
      batch.set(userPartRef, {
        ...campaignData,
        type: 'join'
      });

      const campaignRef = doc(db, 'campaigns', id);
      batch.update(campaignRef, {
        participantCount: increment(1),
        progress: increment(5)
      });

      const userRef = doc(db, 'users', uid);
      batch.set(userRef, { 
        points: increment(points),
        displayName: auth.currentUser.displayName || 'مواطن فاعل',
        role: 'citizen',
        isAnonymous: auth.currentUser.isAnonymous,
        uid: uid,
        updatedAt: serverTimestamp()
      }, { merge: true });

      await batch.commit();

      alert(`يا بطل! شكراً لمشاركتك في "${campaign?.title}". لقد حصلت على ${points} نقطة عمران لمساهمتك في إعمار ولايتك.`);
    } catch (e) {
      console.error(e);
      const errorMsg = handleFirestoreError(e);
      alert(`حدث خطأ أثناء المشاركة: ${JSON.parse(errorMsg).error}`);
    }
  };

  const handleSponsor = async (id: string) => {
    if (!auth.currentUser) return alert("سجل دخولك أولاً للرعاية");
    try {
      const batch = writeBatch(db);
      const uid = auth.currentUser.uid;
      const campaign = campaigns.find(c => c.id === id);
      const amount = 5000;
      const points = 500;
      const campaignData = {
        userId: uid,
        campaignId: id,
        campaignTitle: campaign?.title || 'رعاية عمران',
        campaignImage: campaign?.beforeImageUrl || '',
        pointsEarned: points,
        amount: amount,
        createdAt: serverTimestamp()
      };
      const partId = `${uid}_${Date.now()}`;
      
      const campaignPartRef = doc(db, 'campaigns', id, 'participations', partId);
      batch.set(campaignPartRef, {
        ...campaignData,
        type: 'sponsor'
      });

      const userPartRef = doc(db, 'users', uid, 'participations', partId);
      batch.set(userPartRef, {
        ...campaignData,
        type: 'sponsor'
      });

      const campaignRef = doc(db, 'campaigns', id);
      batch.update(campaignRef, {
        sponsorCount: increment(1),
        currentAmount: increment(amount),
        progress: increment(2)
      });

      const userRef = doc(db, 'users', uid);
      batch.set(userRef, { 
        points: increment(points), 
        uid: uid,
        updatedAt: serverTimestamp()
      }, { merge: true });

      await batch.commit();

      alert(`شكراً لمساهمتك المالية! لقد ساهمت في تقليص فجوة التمويل لمشروع "${campaign?.title}".`);
    } catch (e) {
      console.error(e);
      const errorMsg = handleFirestoreError(e);
      alert(`حدث خطأ أثناء الرعاية: ${JSON.parse(errorMsg).error}`);
    }
  };

  const filteredCampaigns = campaigns
    .filter(c => selectedRegion === 'all' || c.regionId === selectedRegion)
    .sort((a, b) => {
      if (sortBy === 'progress') return (b.progress || 0) - (a.progress || 0);
      if (sortBy === 'participants') return (b.participantCount || 0) - (a.participantCount || 0);
      if (sortBy === 'reward') return (b.pointsReward || 0) - (a.pointsReward || 0);
      return 0;
    });

  const MOCK_LEADERBOARD = [
    { name: 'مجموعة دال الغذائية', points: 45000, contribution: 'برنامج رعاية وطن', location: 'الخرطوم', avatar: 'https://i.pravatar.cc/150?u=dal' },
    { name: 'سارة محمد الحسين', points: 3800, contribution: 'المتطوع الذهبي', location: 'بورتسودان', avatar: 'https://i.pravatar.cc/150?u=sara' },
    { name: 'عمر عثمان الخليفة', points: 3200, contribution: 'سفير العمران', location: 'كسلا', avatar: 'https://i.pravatar.cc/150?u=omar' },
  ];

  return (
    <div className="p-8 space-y-10 pb-32 overflow-y-auto h-full bg-slate-50/30" dir="rtl">
      {/* Header - Tactical Mission Style - Hidden on mobile */}
      <div className="hidden lg:flex justify-between items-end border-r-[6px] border-emerald-500 pr-8 py-2">
        <div className="space-y-2 text-right">
          <div className="flex items-center gap-3 justify-end">
            <div className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
            <h2 className="text-4xl font-black tracking-tighter text-slate-950 font-display uppercase">المبادرات الوطنية</h2>
          </div>
          <p className="text-[11px] font-black font-mono text-slate-400 uppercase tracking-[0.4em] italic">NATIONAL_CAMPAIGNS // SYNC_RECONSTRUCTION</p>
        </div>
        <button className="w-16 h-16 bg-emerald-600 text-white rounded-[2rem] shadow-2xl hover:bg-emerald-700 transition-all flex items-center justify-center border border-white/10 group active:scale-95">
          <Plus size={32} className="group-hover:rotate-90 transition-transform duration-500" />
        </button>
      </div>

      {/* Control Panel - High Fidelity Filters */}
      <div className="space-y-6">
        <div className="space-y-3">
          <div className="flex items-center gap-2 justify-end mb-2">
            <span className="text-[10px] font-black text-slate-400 uppercase tracking-widest">اختيار الولاية المعنية</span>
            <MapPin size={12} className="text-slate-400" />
          </div>
          <div className="flex gap-3 overflow-x-auto pb-4 scrollbar-hide no-scrollbar -mx-2 px-2">
            <button 
              onClick={() => setSelectedRegion('all')}
              className={cn(
                "px-8 py-3.5 rounded-[1.5rem] text-[11px] font-black uppercase tracking-[0.2em] whitespace-nowrap transition-all border-2",
                selectedRegion === 'all' 
                  ? "bg-emerald-600 text-white border-emerald-500 shadow-xl" 
                  : "bg-white text-slate-400 border-slate-100 hover:border-emerald-500 hover:text-emerald-600 shadow-sm"
              )}
            >
              كافة الولايات
            </button>
            {REGIONS.map(region => (
              <button 
                key={region.id}
                onClick={() => setSelectedRegion(region.id)}
                className={cn(
                  "px-8 py-3.5 rounded-[1.5rem] text-[11px] font-black uppercase tracking-[0.2em] whitespace-nowrap transition-all border-2",
                  selectedRegion === region.id 
                    ? "bg-emerald-600 text-white border-emerald-500 shadow-xl" 
                    : "bg-white text-slate-400 border-slate-100 hover:border-emerald-500 hover:text-emerald-600 shadow-sm"
                )}
              >
                {region.name}
              </button>
            ))}
          </div>
        </div>

        <div className="flex items-center justify-between bg-white/50 backdrop-blur-xl p-4 rounded-[2rem] border border-slate-100">
          <div className="flex items-center gap-3">
            {[
              { id: 'progress', label: 'نسبة الإنجاز' },
              { id: 'participants', label: 'كثافة المشاركة' },
              { id: 'reward', label: 'عائد النقاط' }
            ].map(opt => (
              <button
                key={opt.id}
                onClick={() => setSortBy(opt.id as any)}
                className={cn(
                  "px-6 py-2.5 rounded-2xl text-[10px] font-black transition-all",
                  sortBy === opt.id ? "bg-emerald-600 text-white shadow-lg" : "text-slate-400 hover:bg-slate-50"
                )}
              >
                {opt.label}
              </button>
            ))}
          </div>
          <span className="text-[10px] font-black text-slate-400 uppercase tracking-widest font-mono">SORT_BY //</span>
        </div>
      </div>

      {/* Campaign List */}
      <div className="space-y-6">
        <div className="flex justify-between items-center mb-2 px-1">
           <h3 className="text-[10px] font-black text-slate-400 uppercase tracking-widest text-right font-mono">SELECTED_MISSIONS //</h3>
           <Trophy size={14} className="text-amber-400" />
        </div>
        
        {loading && <div className="flex justify-center py-12"><Loader2 className="animate-spin text-emerald-500" size={32} /></div>}
        
        {!loading && filteredCampaigns.length === 0 && (
          <div className="bg-white border-2 border-slate-950 rounded-[4rem] p-24 text-center space-y-6 shadow-[16px_16px_0_0_#f1f5f9]">
            <div className="w-24 h-24 bg-slate-50 rounded-[2.5rem] flex items-center justify-center mx-auto mb-4 border-2 border-slate-950/5">
              <MapPin size={48} className="text-slate-200" />
            </div>
            <h4 className="text-2xl font-black text-slate-900 tracking-tight">لا توجد مهام نشطة حالياً</h4>
            <p className="text-slate-400 font-bold uppercase tracking-widest text-[10px]">استكشف الولايات المجاورة للمساهمة في الإعمار</p>
          </div>
        )}

        {!loading && filteredCampaigns.length > 0 && (
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
            {filteredCampaigns.map((c, idx) => {
              const region = REGIONS.find(r => r.id === c.regionId) || REGIONS[0];
              const sponsor = INSTITUTIONS.find(i => i.id === (c as any).sponsorId) || INSTITUTIONS.find(i => i.id === 'ministry_infra') || INSTITUTIONS[0];
              
              return (
                <motion.div 
                  key={c.id} 
                  initial={{ opacity: 0, scale: 0.95 }}
                  animate={{ opacity: 1, scale: 1 }}
                  transition={{ delay: idx * 0.1, duration: 0.5 }}
                  className="bg-white border-2 border-slate-900 rounded-[3rem] p-8 flex flex-col lg:flex-row gap-8 shadow-[0_15px_40px_rgba(0,0,0,0.02)] group hover:-translate-y-1 hover:shadow-2xl hover:shadow-emerald-100/30 transition-all duration-500 overflow-hidden relative"
                >
              <div className="absolute top-0 right-0 w-32 h-64 opacity-[0.03] pointer-events-none sudan-texture scale-150 rotate-12" />
              
              <div className="w-full lg:w-48 h-48 lg:h-auto rounded-[2.5rem] overflow-hidden shrink-0 relative shadow-xl border-4 border-slate-900 group-hover:rotate-2 transition-transform duration-700">
                <img src={c.beforeImageUrl || region.imageUrl} className="w-full h-full object-cover transition-transform duration-1000 group-hover:scale-125" alt="campaign" />
                <div className="absolute inset-0 bg-slate-950/20 group-hover:bg-transparent transition-colors" />
                <div className="absolute top-4 right-4 px-3 py-1.5 bg-slate-900 text-white rounded-full text-[9px] font-black uppercase tracking-widest border border-white/20">
                   {region.name}
                </div>
              </div>
              
              <div className="flex-1 min-w-0 flex flex-col justify-between py-1 text-right space-y-6">
                <div className="space-y-4">
                  <div className="flex items-center gap-3 justify-end text-[10px] font-black font-mono">
                     <span className="text-emerald-500 uppercase tracking-[0.3em]">MISSION_CODE // {c.id.slice(-6).toUpperCase()}</span>
                  </div>
                  <h4 className="font-black text-slate-950 text-3xl lg:text-4xl tracking-tight group-hover:text-emerald-700 transition-colors leading-[1.1]">{c.title}</h4>
                  
                  <div className="flex items-center gap-3 flex-row-reverse flex-wrap pt-2">
                     <div className="flex items-center gap-2 bg-emerald-50 border-2 border-emerald-500/10 px-4 py-1.5 rounded-full">
                       <div className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
                       <span className="text-[11px] font-black text-emerald-800 uppercase tracking-widest leading-none">{c.status === 'active' ? 'مهمة نشطة' : 'تم الإنجاز'}</span>
                     </div>
                    <div className="flex items-center gap-2 bg-amber-50 border-2 border-amber-500/10 px-4 py-1.5 rounded-full">
                      <Coins size={14} className="text-amber-500" />
                      <span className="text-[11px] font-black text-amber-700 font-mono tracking-tighter leading-none">+{c.pointsReward || 100} PTS</span>
                    </div>
                  </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-6 items-end pt-4">
                  <div className="flex items-center gap-4 flex-row-reverse p-4 bg-slate-50/80 rounded-3xl border-2 border-slate-900/5 group-hover:bg-white group-hover:border-emerald-500/20 transition-all">
                     <div className="w-12 h-12 rounded-2xl overflow-hidden border-2 border-white shrink-0 shadow-sm">
                        <img src={sponsor.logo} className="w-full h-full object-cover" alt="Sponsor" />
                     </div>
                     <div className="flex-1 min-w-0">
                        <p className="text-[9px] font-black text-slate-400 uppercase tracking-widest mb-0.5">NATIONAL_PARTNER</p>
                        <h5 className="text-[12px] font-black text-slate-950 truncate leading-none">{sponsor.name}</h5>
                     </div>
                     <ShieldCheck size={18} className="text-emerald-500 opacity-60" />
                  </div>
                  
                  <div className="space-y-4">
                    <div className="flex justify-between items-end text-[10px] font-black flex-row-reverse">
                      <div className="flex flex-col items-end gap-1.5">
                        <div className="flex items-center gap-2">
                          <Users size={16} className="text-slate-400" />
                          <span className="text-slate-950 uppercase tracking-widest">{c.participantCount || 0} مواطن فاعل</span>
                        </div>
                        <div className="flex items-center gap-2">
                          <HandCoins size={16} className="text-amber-500" />
                          <span className="text-slate-950 font-mono tracking-tight">{c.currentAmount?.toLocaleString() || 0} / {c.targetAmount?.toLocaleString() || '10,000'} SDG</span>
                        </div>
                      </div>
                      <div className="text-right">
                         <p className="text-[9px] font-black text-slate-400 uppercase tracking-widest mb-1.5 font-mono">PROGRESS_SYNC // %</p>
                         <span className="text-3xl font-black font-mono italic text-slate-950 leading-none">{c.progress || 0}</span>
                      </div>
                    </div>
                    <div className="h-4 bg-slate-100 rounded-full overflow-hidden relative border-2 border-slate-950/5 shadow-inner">
                      <motion.div 
                        initial={{ width: 0 }}
                        animate={{ width: `${c.progress || 0}%` }}
                        className="h-full bg-emerald-500 rounded-full shadow-[0_0_20px_#10b981]" 
                      />
                    </div>
                  </div>
                </div>
              </div>
              
              <div className="flex flex-col gap-3 justify-center">
                <button 
                  onClick={() => handleJoin(c.id, c.pointsReward || 100)}
                  className="w-14 h-14 bg-emerald-600 rounded-[1.25rem] text-white hover:bg-emerald-700 transition-all duration-500 transform rotate-180 active:scale-90 shadow-xl border border-white/10 flex items-center justify-center group"
                >
                  <ArrowUpRight size={24} strokeWidth={3} className="group-hover:-translate-y-1 group-hover:translate-x-1 transition-transform" />
                </button>
                <button 
                  onClick={() => handleSponsor(c.id)}
                  className="w-14 h-14 bg-white rounded-[1.25rem] text-rose-500 border-2 border-slate-50 hover:bg-rose-500 hover:text-white hover:border-rose-500 transition-all duration-500 active:scale-90 shadow-lg flex items-center justify-center group"
                >
                  <Heart size={24} strokeWidth={3} fill={c.currentAmount ? "currentColor" : "none"} className="group-hover:scale-125 transition-transform" />
                </button>
              </div>
            </motion.div>
          );
        })}
      </div>
    )}

      </div>

      {/* Impact Stats */}
      <section className="space-y-6">
        <div className="flex justify-between items-center px-1 flex-row-reverse text-right">
          <h3 className="text-[10px] font-black text-slate-400 uppercase tracking-widest font-mono">NATIONAL_HONOR_ROLL //</h3>
          <div className="flex items-center gap-2 text-amber-500">
            <Crown size={16} />
            <span className="text-xl font-bold font-display tracking-tight text-slate-900 uppercase">لوحة الشرف</span>
          </div>
        </div>

        <div className="bg-white border-2 border-slate-50 rounded-[3.5rem] overflow-hidden shadow-sm shadow-slate-100">
          {MOCK_LEADERBOARD.map((hero, idx) => (
            <div 
              key={idx} 
              className={cn(
                "p-8 flex items-center justify-between border-b border-slate-50 last:border-0",
                idx === 0 ? "bg-emerald-50/20" : ""
              )}
            >
              <div className="flex items-center gap-6">
                <div className="text-right">
                   <p className="text-xl font-black text-slate-950 font-display">{hero.name}</p>
                   <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest">{hero.location} // {hero.contribution}</p>
                </div>
                <div className={cn(
                  "w-16 h-16 rounded-[1.5rem] flex items-center justify-center font-black relative overflow-hidden shadow-lg border-4 border-white",
                  idx === 0 ? "bg-emerald-600 text-white" : "bg-slate-100 text-slate-400"
                )}>
                  <img src={hero.avatar} className="absolute inset-0 w-full h-full object-cover opacity-60 grayscale" alt="" />
                  <span className="relative z-10 text-2xl font-mono">#{idx + 1}</span>
                  {idx === 0 && (
                    <div className="absolute top-0 right-0 p-1 bg-amber-400 shadow-xl">
                      <Crown size={12} className="text-slate-950" fill="currentColor" />
                    </div>
                  )}
                </div>
              </div>

              <div className="text-left space-y-1">
                <div className="flex items-center gap-2 justify-end mb-1">
                   <TrendingUp size={14} className="text-emerald-500" />
                   <p className="text-2xl font-black text-slate-900 font-mono tracking-tighter">{hero.points.toLocaleString()}</p>
                </div>
                <div className="px-3 py-1 bg-emerald-600 rounded-lg inline-block">
                   <span className="text-[9px] font-black text-white uppercase tracking-[0.2em]">{hero.contribution.toUpperCase()}</span>
                </div>
              </div>
            </div>
          ))}
          <button className="w-full py-6 text-[11px] font-black text-slate-400 uppercase tracking-[0.4em] hover:bg-emerald-50 hover:text-emerald-600 transition-all border-t border-slate-50 font-mono">
            LOAD_FULL_RANKINGS_REPORTS // VIEW_ALL
          </button>
        </div>
      </section>

      {/* Footer Impact Banner */}
      <div className="bg-emerald-600 rounded-[4rem] p-12 space-y-8 text-white overflow-hidden relative shadow-2xl border border-emerald-500/30">
        <div className="absolute top-0 right-0 w-96 h-full opacity-[0.08] pointer-events-none sudan-texture scale-150 rotate-45" />
        <div className="relative z-10 space-y-6 text-right">
          <div className="w-20 h-20 bg-white/20 rounded-[2rem] flex items-center justify-center text-white backdrop-blur-2xl float-right mb-4 border border-white/30 shadow-inner">
            <CheckCircle2 size={40} />
          </div>
          <div className="clear-both space-y-3">
            <h3 className="text-4xl font-black font-display tracking-tighter">٢٨ مشروع مكتمل في شهر واحد</h3>
            <p className="text-sm text-emerald-50 font-medium leading-[1.8] max-w-2xl ml-auto opacity-90">هذه الإنجازات هي ثمار سواعد العمران التي تمتد في كافة أصقاع الوطن، معيدة بناء ما دمرته الأزمات ومؤسسة لمرحلة من النهضة الشاملة.</p>
          </div>
          
          <div className="pt-8 border-t border-white/20 flex gap-16 justify-end items-center">
            <div className="text-right">
              <p className="text-[10px] font-black text-emerald-200 uppercase tracking-[0.4em] mb-2 font-mono">VOLUNTEER_FORCE</p>
              <p className="text-3xl font-black font-mono text-white tracking-tighter leading-none">+١,٢٠٠</p>
            </div>
            <div className="text-right">
              <p className="text-[10px] font-black text-emerald-200 uppercase tracking-[0.4em] mb-2 font-mono">DISTRIBUTED_CREDITS</p>
              <p className="text-3xl font-black font-mono text-amber-300 tracking-tighter leading-none">٤٥٠,٠٠٠</p>
            </div>
            <div className="text-right">
              <p className="text-[10px] font-black text-emerald-200 uppercase tracking-[0.4em] mb-2 font-mono">TOTAL_IMPACT_H</p>
              <p className="text-3xl font-black font-mono text-white tracking-tighter leading-none">١٢,٤٠٠</p>
            </div>
          </div>
        </div>
        <div className="absolute -left-40 -bottom-40 w-[30rem] h-[30rem] bg-emerald-400/20 blur-[150px] rounded-full pointer-events-none" />
      </div>
    </div>
  );
}
