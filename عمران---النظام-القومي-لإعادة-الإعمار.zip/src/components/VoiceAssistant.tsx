import React, { useState, useRef, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Mic, MicOff, Volume2, VolumeX, Loader2, X, Bot } from 'lucide-react';
import { GoogleGenAI, Modality } from "@google/genai";
import { cn } from '../lib/utils';

const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY });

const SUDANESE_VOICE_INSTRUCTIONS = `
You are 'Umran Voice Assistant' (مساعد عمران الصوتي).
Your personality:
- Extremely warm, hospitable, and community-oriented Sudanese assistant.
- Use a rich, expressive 'Sudanese Arabic Dialect' (اللهجة السودانية) that sounds natural and welcoming.
- Use authentic Sudanese expressions generously: 'حبابك عشرة', 'يا زول يا طيب', 'يا بطل', 'تسلم كتير', 'أبشر بالخير', 'على الراس والعين'.
- Maintain a patient and helpful tone, reflecting the Sudanese values of "Karam" (hospitality) and "Fazza" (communal aid).
- Help users report infrastructure problems (Water, Roads, Electricity, Waste) via voice tools.
- Keep responses relatively concise but emotionally resonant—make the user feel heard and appreciated.
- Reassure users that their contribution is a vital step in rebuilding our neighborhoods.
`;

export default function VoiceAssistant({ 
  onClose, 
  context, 
  tools, 
  onToolCall 
}: { 
  onClose: () => void; 
  context?: string; 
  tools?: any[]; 
  onToolCall?: (call: any) => Promise<any>;
}) {
  const [isActive, setIsActive] = useState(false);
  const [isConnecting, setIsConnecting] = useState(false);
  const [isListening, setIsListening] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const sessionRef = useRef<any>(null);
  const audioContextRef = useRef<AudioContext | null>(null);
  const processorRef = useRef<ScriptProcessorNode | null>(null);
  const microphoneRef = useRef<MediaStreamAudioSourceNode | null>(null);
  const streamRef = useRef<MediaStream | null>(null);

  const startSession = async () => {
    setIsConnecting(true);
    setError(null);

    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      streamRef.current = stream;

      const audioContext = new (window.AudioContext || (window as any).webkitAudioContext)({ sampleRate: 16000 });
      audioContextRef.current = audioContext;

      const session = await ai.live.connect({
        model: "gemini-3.1-flash-live-preview",
        config: {
          responseModalities: [Modality.AUDIO],
          speechConfig: {
            voiceConfig: { prebuiltVoiceConfig: { voiceName: "Kore" } },
          },
          systemInstruction: SUDANESE_VOICE_INSTRUCTIONS + (context ? `\n\nContext for this session: ${context}` : ""),
          tools: tools ? [{ functionDeclarations: tools }] : [],
          inputAudioTranscription: {},
          outputAudioTranscription: {},
        },
        callbacks: {
          onopen: () => {
            setIsConnecting(false);
            setIsActive(true);
            setIsListening(true);
            
            // Setup microphone streaming
            const source = audioContext.createMediaStreamSource(stream);
            const processor = audioContext.createScriptProcessor(4096, 1, 1);
            
            microphoneRef.current = source;
            processorRef.current = processor;

            processor.onaudioprocess = (e) => {
              const inputData = e.inputBuffer.getChannelData(0);
              // Convert Float32 to Int16 PCM
              const pcmData = new Int16Array(inputData.length);
              for (let i = 0; i < inputData.length; i++) {
                pcmData[i] = Math.max(-1, Math.min(1, inputData[i])) * 0x7FFF;
              }
              
              const base64Data = btoa(String.fromCharCode(...new Uint8Array(pcmData.buffer)));
              
              session.sendRealtimeInput({
                audio: { data: base64Data, mimeType: 'audio/pcm;rate=16000' }
              });
            };

            source.connect(processor);
            processor.connect(audioContext.destination);
          },
          onmessage: async (message) => {
            // Handle audio output
            const base64Audio = message.serverContent?.modelTurn?.parts?.[0]?.inlineData?.data;
            if (base64Audio) {
              playAudioResponse(base64Audio);
            }
            
            // Handle tool calls
            const toolCall = message.toolCall;
            if (toolCall && onToolCall) {
              const functionCalls = toolCall.functionCalls;
              const functionResponses = [];
              
              for (const call of functionCalls) {
                const result = await onToolCall(call);
                functionResponses.push({
                  name: call.name,
                  response: result,
                  id: call.id
                });
              }
              
              session.sendToolResponse({ functionResponses });
            }

            if (message.serverContent?.interrupted) {
              stopPlayback();
            }
          },
          onerror: (err) => {
            console.error("Live API Error:", err);
            setError("حدث خطأ في الاتصال. حاول مرة ثانية.");
            stopSession();
          },
          onclose: () => {
             setIsActive(false);
             setIsListening(false);
          }
        }
      });

      sessionRef.current = session;
    } catch (err) {
      console.error("Mic access error:", err);
      setError("لا يمكن الوصول للميكروفون. تأكد من الأذونات.");
      setIsConnecting(false);
    }
  };

  const playAudioResponse = (base64Data: string) => {
    if (!audioContextRef.current) return;
    
    const binary = atob(base64Data);
    const bytes = new Uint8Array(binary.length);
    for (let i = 0; i < binary.length; i++) {
      bytes[i] = binary.charCodeAt(i);
    }
    
    const pcmData = new Int16Array(bytes.buffer);
    const floatData = new Float32Array(pcmData.length);
    for (let i = 0; i < pcmData.length; i++) {
      floatData[i] = pcmData[i] / 0x7FFF;
    }

    const buffer = audioContextRef.current.createBuffer(1, floatData.length, 16000);
    buffer.getChannelData(0).set(floatData);

    const source = audioContextRef.current.createBufferSource();
    source.buffer = buffer;
    source.connect(audioContextRef.current.destination);
    source.start();
  };

  const stopPlayback = () => {
    // Simple stop logic: in a full implementation we'd track active sources
  };

  const stopSession = () => {
    if (sessionRef.current) {
      sessionRef.current.close();
      sessionRef.current = null;
    }
    
    if (processorRef.current) {
      processorRef.current.disconnect();
      processorRef.current = null;
    }
    
    if (microphoneRef.current) {
      microphoneRef.current.disconnect();
      microphoneRef.current = null;
    }
    
    if (streamRef.current) {
      streamRef.current.getTracks().forEach(track => track.stop());
      streamRef.current = null;
    }

    if (audioContextRef.current) {
      audioContextRef.current.close();
      audioContextRef.current = null;
    }

    setIsActive(false);
    setIsListening(false);
  };

  useEffect(() => {
    return () => stopSession();
  }, []);

  return (
    <motion.div 
      initial={{ opacity: 0, scale: 0.9 }}
      animate={{ opacity: 1, scale: 1 }}
      exit={{ opacity: 0, scale: 0.9 }}
      className="absolute inset-0 bg-emerald-600/95 backdrop-blur-xl z-[60] flex flex-col items-center justify-center p-8 text-white text-center"
      dir="rtl"
    >
      <button 
        onClick={onClose}
        className="absolute top-6 left-6 p-2 bg-white/10 rounded-full hover:bg-white/20 transition-colors"
      >
        <X size={24} />
      </button>

      <div className="flex flex-col items-center gap-8 w-full">
        <div className="relative">
          <motion.div 
            animate={{ 
              scale: isListening ? [1, 1.2, 1] : 1,
              opacity: isListening ? [0.5, 0.8, 0.5] : 0.2
            }}
            transition={{ repeat: Infinity, duration: 2 }}
            className="absolute inset-0 bg-white rounded-full blur-3xl"
          />
          <div className="w-32 h-32 bg-white rounded-full flex items-center justify-center shadow-2xl relative z-10">
            <Bot size={64} className="text-emerald-600" />
          </div>
        </div>

        <div className="space-y-2">
          <h2 className="text-2xl font-bold">مساعد عمران الصوتي</h2>
          <p className="text-emerald-100 text-sm opacity-80">تحدث معي بلهجتك السودانية الجميلة</p>
        </div>

        {error ? (
          <div className="p-4 bg-red-500/20 rounded-2xl border border-red-500/30 text-sm">
            {error}
          </div>
        ) : (
          <div className="h-12 flex items-center justify-center">
            {isConnecting ? (
              <div className="flex items-center gap-3">
                <Loader2 className="animate-spin" />
                <span>جاري الاتصال...</span>
              </div>
            ) : isActive ? (
              <div className="flex items-center gap-4">
                <motion.div 
                  animate={{ height: [4, 16, 8, 20, 4] }}
                  transition={{ repeat: Infinity, duration: 1 }}
                  className="w-1 bg-white rounded-full"
                />
                <motion.div 
                   animate={{ height: [8, 4, 20, 12, 8] }}
                   transition={{ repeat: Infinity, duration: 0.8 }}
                   className="w-1 bg-white rounded-full"
                />
                <motion.div 
                   animate={{ height: [20, 12, 4, 16, 20] }}
                   transition={{ repeat: Infinity, duration: 1.2 }}
                   className="w-1 bg-white rounded-full"
                />
                <span className="font-medium tracking-widest uppercase text-xs">جاري الاستماع</span>
              </div>
            ) : null}
          </div>
        )}

        <button 
          onClick={isActive ? stopSession : startSession}
          className={cn(
            "w-20 h-20 rounded-full flex items-center justify-center shadow-xl transition-all active:scale-90",
            isActive ? "bg-red-500 hover:bg-red-600" : "bg-white text-emerald-600 hover:bg-emerald-50"
          )}
        >
          {isActive ? <MicOff size={32} /> : <Mic size={32} />}
        </button>
        
        <p className="text-[10px] text-emerald-200 uppercase tracking-[0.2em] font-bold">
          {isActive ? "اضغط لإيقاف المساعد" : "اضغط لبدء المحادثة"}
        </p>
      </div>
    </motion.div>
  );
}
