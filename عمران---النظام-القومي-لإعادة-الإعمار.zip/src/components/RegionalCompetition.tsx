import React from 'react';
import { motion } from 'motion/react';
import { Trophy, Users, MessageSquare, TrendingUp, Award, Crown, Building } from 'lucide-react';
import { REGIONS } from '../constants';
import { cn } from '../lib/utils';

export default function RegionalCompetition() {
  const sortedRegions = [...REGIONS].sort((a, b) => b.totalPoints - a.totalPoints);
  
  return (
    <div className="space-y-8 pb-10">
      <div className="flex items-center justify-between border-r-4 border-emerald-500 pr-4">
        <div className="text-right">
          <h3 className="text-2xl font-black text-slate-800 font-display tracking-tight uppercase">مؤشر التفاعل الميداني</h3>
          <p className="text-[10px] font-black text-emerald-600 uppercase tracking-[0.3em] font-mono italic">REGIONAL_TRACKER // LIVE_SITREP</p>
        </div>
        <div className="p-4 rounded-[1.5rem] bg-emerald-50 text-emerald-600 border border-emerald-100 shadow-sm rotate-3">
          <Trophy size={24} strokeWidth={2.5} />
        </div>
      </div>

      <div className="grid grid-cols-1 gap-6">
        {sortedRegions.map((region, index) => (
          <motion.div
            key={region.id}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: index * 0.1 }}
            className="group relative overflow-hidden bento-inner !p-0 border-slate-100 bg-white hover:border-emerald-500 hover:shadow-xl transition-all duration-500 rounded-[3rem]"
          >
            <div className="absolute top-0 right-0 w-48 h-full opacity-[0.04] pointer-events-none sudan-texture z-10 scale-125" />
            
            <div className="flex flex-col sm:flex-row items-stretch sm:items-center">
              {/* Region Visual Header */}
              <div className="relative w-full sm:w-40 h-32 shrink-0 overflow-hidden group-hover:rotate-1 transition-transform duration-700">
                <img 
                  src={region.imageUrl} 
                  alt={region.name} 
                  className="w-full h-full object-cover transition-transform duration-1000 group-hover:scale-125"
                  referrerPolicy="no-referrer"
                />
                <div className="absolute inset-0 bg-gradient-to-l from-white via-white/40 to-transparent hidden sm:block" />
                <div className="absolute inset-x-0 bottom-0 h-1/2 bg-gradient-to-t from-white to-transparent sm:hidden" />
                
                {index === 0 && (
                  <div className="absolute top-4 right-4 bg-amber-400 text-white p-2 rounded-xl shadow-xl shadow-amber-200 rotate-12 group-hover:rotate-0 transition-transform">
                    <Crown size={18} fill="currentColor" />
                  </div>
                )}
              </div>

              <div className="flex-1 p-6 text-right">
                <div className="flex flex-col sm:flex-row justify-between items-start mb-4 gap-4 sm:gap-0">
                  <div className="flex flex-col items-start px-2 w-full sm:w-auto">
                     <div className="flex-row-reverse flex items-center gap-2 mb-2">
                         <span className="text-[9px] font-black text-slate-400 uppercase tracking-widest font-mono">INTENSITY_LVL</span>
                         <div className="w-1.5 h-1.5 rounded-full bg-emerald-300 animate-pulse" />
                     </div>
                    <div className="h-2 w-full sm:w-32 bg-slate-50 rounded-full overflow-hidden border border-slate-100 shadow-inner">
                      <motion.div 
                        initial={{ width: 0 }}
                        animate={{ width: `${(region.totalPoints / sortedRegions[0].totalPoints) * 100}%` }}
                        className="h-full bg-emerald-500 shadow-[0_0_10px_#10b981]" 
                      />
                    </div>
                  </div>
                  <div>
                    <div className="flex items-center gap-2 justify-end mb-1">
                       <span className="text-[9px] font-black text-emerald-400 uppercase tracking-[0.2em] font-mono italic">OPERATIONAL_DATA</span>
                       <Building size={12} className="text-slate-300" />
                    </div>
                    <h4 className="text-2xl font-black text-slate-800 font-display tracking-tight leading-none mb-1">{region.name}</h4>
                    <span className="text-[11px] font-black text-slate-400 uppercase tracking-[0.4em] font-mono italic">CAPITAL // {region.capital}</span>
                  </div>
                </div>

                <div className="flex gap-8 justify-start">
                  <div className="flex flex-col items-start gap-1">
                     <span className="text-[9px] font-black text-slate-300 uppercase tracking-widest leading-none">TOTAL_CREDITS</span>
                     <div className="flex items-center gap-2">
                       <TrendingUp size={16} className="text-emerald-500" />
                       <span className="text-xl font-black text-slate-800 font-mono tracking-tighter">{region.totalPoints.toLocaleString()}</span>
                     </div>
                  </div>
                  <div className="flex flex-col items-start gap-1">
                     <span className="text-[9px] font-black text-slate-300 uppercase tracking-widest leading-none">FIELD_REPORTS</span>
                     <div className="flex items-center gap-2">
                       <MessageSquare size={16} className="text-slate-400" />
                       <span className="text-xl font-black text-slate-800 font-mono tracking-tighter">{region.totalReports}</span>
                     </div>
                  </div>
                </div>
              </div>

              <div className="px-8 py-4 border-t sm:border-t-0 sm:border-r-2 border-slate-50 flex flex-row sm:flex-col items-center justify-between sm:justify-center bg-slate-50/50 group-hover:bg-slate-950 group-hover:text-white transition-all duration-500">
                <span className="text-[10px] font-black text-slate-300 uppercase tracking-[0.4em] sm:mb-1 font-mono group-hover:text-emerald-400">RANK</span>
                <span className="text-3xl sm:text-4xl font-black font-mono italic tracking-tighter leading-none">#{index + 1}</span>
              </div>
            </div>
          </motion.div>
        ))}
      </div>
    </div>
  );
}
