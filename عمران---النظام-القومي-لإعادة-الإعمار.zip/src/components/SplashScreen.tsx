import React, { useEffect, useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Droplets, Zap, MapPin, Trash2, Shovel, AlertTriangle, Bell, Info } from 'lucide-react';
import { MOCK_ALERTS } from '../constants';
import { cn } from '../lib/utils';

export default function SplashScreen({ onFinish }: { onFinish: () => void }) {
  const [progress, setProgress] = useState(0);
  const [alertIndex, setAlertIndex] = useState(0);
  const [loadingText, setLoadingText] = useState('جاري تهيئة النظام الرقمي...');

  const loadingMessages = [
    'جاري تهيئة النظام الرقمي...',
    'تحميل بيانات الميدان الوطني...',
    'مزامنة البلاغات الحكومية...',
    'تأمين قنوات التواصل المجتمعي...',
    'جاري تحسين التجربة الوطنية...'
  ];

  useEffect(() => {
    const textInterval = setInterval(() => {
      setLoadingText(prev => {
        const nextIdx = (loadingMessages.indexOf(prev) + 1) % loadingMessages.length;
        return loadingMessages[nextIdx];
      });
    }, 2000);

    const alertTimer = setInterval(() => {
      setAlertIndex(prev => (prev + 1) % MOCK_ALERTS.length);
    }, 3000);

    const timer = setInterval(() => {
      setProgress(prev => {
        if (prev >= 100) {
          clearInterval(timer);
          clearInterval(alertTimer);
          setTimeout(onFinish, 1200);
          return 100;
        }
        return prev + 1.5;
      });
    }, 40);
    return () => {
      clearInterval(timer);
      clearInterval(alertTimer);
    };
  }, [onFinish]);

  return (
    <motion.div 
      initial={{ opacity: 1 }}
      exit={{ opacity: 0, scale: 1.1, filter: 'blur(20px)' }}
      transition={{ duration: 0.8 }}
      className="fixed inset-0 z-[100] bg-slate-950 flex flex-col items-center justify-center p-8 overflow-hidden"
      dir="rtl"
    >
      {/* Enhanced Atmospheric Effects */}
      <div className="absolute inset-0 bg-[#04100b]" />
      <div className="absolute inset-0 opacity-10 sudan-texture mix-blend-overlay rotate-12 scale-110" />
      
      {/* Dynamic Light Sources */}
      <motion.div 
        animate={{ 
          opacity: [0.1, 0.2, 0.1],
          scale: [1, 1.2, 1] 
        }}
        transition={{ duration: 8, repeat: Infinity }}
        className="absolute top-[-20%] left-[-10%] w-[800px] h-[800px] bg-emerald-600/30 rounded-full blur-[160px]" 
      />
      <motion.div 
        animate={{ 
          opacity: [0.05, 0.15, 0.05],
          scale: [1.2, 1, 1.2] 
        }}
        transition={{ duration: 10, repeat: Infinity }}
        className="absolute bottom-[-20%] right-[-10%] w-[800px] h-[800px] bg-amber-600/20 rounded-full blur-[160px]" 
      />
      
      {/* Animated Dust/Particles Simulation Effect */}
      <div className="absolute inset-0 pointer-events-none opacity-20">
        {[...Array(20)].map((_, i) => (
          <motion.div
            key={i}
            initial={{ 
              x: Math.random() * 1000 - 500, 
              y: Math.random() * 1000 - 500,
              opacity: 0 
            }}
            animate={{ 
              y: [null, Math.random() * -200],
              opacity: [0, 1, 0] 
            }}
            transition={{ 
              duration: 5 + Math.random() * 5, 
              repeat: Infinity,
              delay: Math.random() * 5 
            }}
            className="absolute w-1 h-1 bg-white rounded-full blur-[1px]"
            style={{ 
              left: `${Math.random() * 100}%`,
              top: `${Math.random() * 100}%`
            }}
          />
        ))}
      </div>

      <motion.div
        initial={{ scale: 0.8, opacity: 0 }}
        animate={{ scale: 1, opacity: 1 }}
        transition={{ duration: 2, ease: [0.22, 1, 0.36, 1] }}
        className="relative flex flex-col items-center justify-center w-full max-w-2xl h-[450px]"
      >
        {/* Detailed Map Illustration */}
        <div className="relative">
          <svg 
            viewBox="0 0 200 240" 
            className="w-48 sm:w-64 h-auto fill-emerald-500/5 stroke-emerald-500/20 stroke-[1] drop-shadow-[0_0_80px_rgba(16,185,129,0.15)]"
            xmlns="http://www.w3.org/2000/svg"
          >
            <motion.path 
              initial={{ pathLength: 0 }}
              animate={{ pathLength: 1 }}
              transition={{ duration: 4, ease: "easeInOut" }}
              d="M50 20 L80 15 L110 5 L140 10 L160 30 L170 60 L185 85 L180 110 L165 140 L160 170 L145 200 L130 225 L100 235 L70 220 L45 230 L35 210 L15 180 L5 150 L10 120 L25 90 L35 45 Z"
              fill="none"
              stroke="url(#cinematicMapGradient)"
              className="stroke-[2]"
            />
            <defs>
              <linearGradient id="cinematicMapGradient" x1="0%" y1="0%" x2="100%" y2="100%">
                <stop offset="0%" stopColor="#10b981" stopOpacity="0.8" />
                <stop offset="50%" stopColor="#34d399" stopOpacity="0.4" />
                <stop offset="100%" stopColor="#10b981" stopOpacity="0.8" />
              </linearGradient>
            </defs>
          </svg>
        </div>

        {/* Orbiting Icons - Adjusted Layout for better hierarchy */}
        <AnimatePresence>
          {[
            { Icon: Droplets, color: 'emerald', label: 'إعمار المياه', delay: 1.5, angle: -90, radiusX: 130, radiusY: 150 },
            { Icon: Zap, color: 'amber', label: 'ربط الشبكة', delay: 1.7, angle: -18, radiusX: 130, radiusY: 150 },
            { Icon: MapPin, color: 'rose', label: 'رسم المسارات', delay: 1.9, angle: 54, radiusX: 130, radiusY: 150 },
            { Icon: Trash2, color: 'teal', label: 'تطهير البيئة', delay: 2.1, angle: 126, radiusX: 130, radiusY: 150 },
            { Icon: Shovel, color: 'orange', label: 'تشييد البناء', delay: 2.3, angle: 198, radiusX: 130, radiusY: 150 },
          ].map((item, i) => (
            <motion.div
              key={i}
              initial={{ opacity: 0, scale: 0.5, y: 20 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              transition={{ delay: item.delay, type: 'spring', damping: 12 }}
              className="absolute flex flex-col items-center"
              style={{
                top: `calc(50% + ${item.radiusY * Math.sin((item.angle * Math.PI) / 180)}px)`,
                left: `calc(50% + ${item.radiusX * Math.cos((item.angle * Math.PI) / 180)}px)`,
                transform: 'translate(-50%, -50%)'
              }}
            >
              <div className={cn(
                "w-12 h-12 sm:w-16 sm:h-16 rounded-[2rem] bg-slate-900/60 backdrop-blur-xl border border-white/10 flex items-center justify-center mb-3 shadow-2xl transition-all hover:scale-110 group",
                item.color === 'emerald' && "text-emerald-400 border-emerald-500/20",
                item.color === 'amber' && "text-amber-400 border-amber-500/20",
                item.color === 'rose' && "text-rose-400 border-rose-500/20",
                item.color === 'teal' && "text-teal-400 border-teal-500/20",
                item.color === 'orange' && "text-orange-400 border-orange-500/20",
              )}>
                <item.Icon size={24} className="sm:w-7 sm:h-7" />
                <div className="absolute inset-0 rounded-[2rem] bg-current opacity-0 blur-xl group-hover:opacity-20 transition-opacity" />
              </div>
              <span className="text-[9px] font-black text-slate-300 uppercase tracking-[0.2em] bg-white/5 border border-white/5 px-3 py-1 rounded-full whitespace-nowrap opacity-60">
                {item.label}
              </span>
            </motion.div>
          ))}
        </AnimatePresence>

        {/* Central Logo - Cinematic Stagger */}
        <div className="absolute flex flex-col items-center">
          <motion.div
            initial={{ opacity: 0, letterSpacing: '0.5em', filter: 'blur(10px)' }}
            animate={{ opacity: 1, letterSpacing: '-0.02em', filter: 'blur(0px)' }}
            transition={{ delay: 1, duration: 1.5, ease: [0.16, 1, 0.3, 1] }}
            className="relative"
          >
            <h1 className="text-8xl sm:text-[10rem] font-black text-white font-display leading-none mb-2 tracking-tighter mix-blend-overlay">
              عمران
            </h1>
            <h1 className="absolute inset-0 text-8xl sm:text-[10rem] font-black text-white font-display leading-none mb-2 tracking-tighter opacity-10 blur-sm">
              عمران
            </h1>
            <h1 className="absolute inset-0 text-8xl sm:text-[10rem] font-black text-transparent stroke-white/20 stroke-[0.5px] font-display leading-none mb-2 tracking-tighter">
              عمران
            </h1>
          </motion.div>
          
          <motion.div
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 0.6, y: 0 }}
            transition={{ delay: 2, duration: 1 }}
            className="flex items-center gap-3"
          >
            <div className="h-[1px] w-6 bg-emerald-500" />
            <span className="text-[10px] font-black text-emerald-400 uppercase tracking-[0.6em]">RECONSTRUCTION</span>
            <div className="h-[1px] w-6 bg-emerald-500" />
          </motion.div>
        </div>
      </motion.div>

      {/* Floating System Status Badge */}
      <motion.div
        initial={{ opacity: 0, x: 20 }}
        animate={{ opacity: 1, x: 0 }}
        transition={{ delay: 2.5 }}
        className="fixed top-8 right-8 flex items-center gap-4 bg-white/5 border border-white/10 p-4 rounded-[2rem] backdrop-blur-xl"
      >
        <div className="w-10 h-10 rounded-2xl bg-emerald-500/20 flex items-center justify-center text-emerald-400">
          <Zap size={18} />
        </div>
        <div>
          <p className="text-[8px] font-black text-slate-500 uppercase tracking-widest">Digital Infrastructure</p>
          <p className="text-[10px] font-bold text-white">Sudan Central Hub</p>
        </div>
      </motion.div>

      {/* Ticker Section - Refined for Cinematic feel */}
      <div className="absolute bottom-32 left-0 right-0 py-6 border-y border-white/5 bg-gradient-to-r from-transparent via-white/5 to-transparent backdrop-blur-sm">
        <AnimatePresence mode="wait">
          <motion.div
            key={alertIndex}
            initial={{ opacity: 0, filter: 'blur(5px)', x: -20 }}
            animate={{ opacity: 1, filter: 'blur(0px)', x: 0 }}
            exit={{ opacity: 0, filter: 'blur(5px)', x: 20 }}
            transition={{ duration: 0.6 }}
            className="max-w-xl mx-auto flex items-center justify-center gap-6"
          >
             <span className="shrink-0 px-3 py-1 bg-emerald-600 rounded-lg text-white text-[8px] font-black uppercase tracking-widest">
               {MOCK_ALERTS[alertIndex].institutionName}
             </span>
             <p className="text-sm font-medium text-slate-100 text-center leading-relaxed">
               {MOCK_ALERTS[alertIndex].title} <span className="opacity-40 font-light mx-2">|</span> {MOCK_ALERTS[alertIndex].message}
             </p>
          </motion.div>
        </AnimatePresence>
      </div>

      {/* Enhanced Progress Indicator */}
      <div className="absolute bottom-12 left-1/2 -translate-x-1/2 w-full max-w-sm px-8 space-y-4">
        <div className="flex justify-between items-baseline">
          <motion.p 
            key={loadingText}
            initial={{ opacity: 0 }}
            animate={{ opacity: 0.5 }}
            className="text-[9px] font-black text-slate-300 uppercase tracking-[0.2em]"
          >
            {loadingText}
          </motion.p>
          <span className="text-[10px] font-mono text-emerald-500 font-black">{Math.floor(progress)}%</span>
        </div>
        <div className="relative h-[2px] bg-white/5 rounded-full overflow-hidden">
          <motion.div 
            className="absolute top-0 bottom-0 left-0 bg-emerald-500 shadow-[0_0_20px_#10b981]"
            initial={{ width: 0 }}
            animate={{ width: `${progress}%` }}
            transition={{ ease: "linear" }}
          />
        </div>
      </div>

    </motion.div>
  );
}
