import React, { useState, useRef } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Camera, Mic, MapPin, Send, ArrowRight, Loader2, Check, Droplets, Zap, Trash2, MapIcon, X, Sparkles, ScanSearch, HelpCircle, CheckCircle2, ShieldCheck } from 'lucide-react';
import { collection, addDoc, serverTimestamp, setDoc, doc, increment } from 'firebase/firestore';
import { db, auth } from '../lib/firebase';
import { cn } from '../lib/utils';
import { GoogleGenAI } from "@google/genai";

const STEPS = [
  { id: 1, title: 'الوسائط' },
  { id: 2, title: 'التفاصيل' },
  { id: 3, title: 'المراجعة' },
];

const CATEGORIES = [
  { id: 'road', label: 'طرق', icon: <MapPin size={24} />, color: 'bg-emerald-50 text-emerald-600' },
  { id: 'water', label: 'مياه', icon: <Droplets size={24} />, color: 'bg-blue-50 text-blue-600' },
  { id: 'electricity', label: 'كهرباء', icon: <Zap size={24} />, color: 'bg-amber-50 text-amber-600' },
  { id: 'waste', label: 'نفايات', icon: <Trash2 size={24} />, color: 'bg-rose-50 text-rose-600' },
  { id: 'other', label: 'عام / أخرى', icon: <HelpCircle size={24} />, color: 'bg-slate-50 text-slate-600' },
];

export default function IssueReport({ onComplete }: { onComplete: () => void }) {
  const [step, setStep] = useState(1);
  const [isRecording, setIsRecording] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [uploadProgress, setUploadProgress] = useState(0);
  const [recordingDuration, setRecordingDuration] = useState(0);
  const recordingTimerRef = useRef<any>(null);
  const [issueType, setIssueType] = useState('');
  const [interactionType, setInteractionType] = useState<'report' | 'suggestion' | 'inquiry'>('report');
  const [description, setDescription] = useState('');
  const [manualAddress, setManualAddress] = useState('الرياض، الخرطوم');
  const [currentCoords, setCurrentCoords] = useState<{ lat: number; lng: number } | null>(null);
  const [isLocating, setIsLocating] = useState(false);
  const [severity, setSeverity] = useState<1 | 2 | 3>(2);
  const [attachedImages, setAttachedImages] = useState<string[]>([]);
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [trackingId] = useState(() => {
    const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
    let result = 'BN-';
    for (let i = 0; i < 6; i++) {
      result += chars.charAt(Math.floor(Math.random() * chars.length));
    }
    return result;
  });

  const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY || '' });

  const analyzeImage = async (base64Data: string) => {
    setIsAnalyzing(true);
    try {
      const response = await ai.models.generateContent({
        model: "gemini-3.1-pro-preview",
        contents: [
          {
            parts: [
              { text: "Analyze this image of a Sudanese infrastructure problem. Determine the issue type (road, water, electricity, waste, or other) and provide a concise description in Sudanese Arabic (Ammiya). Also, assess the visual cues to determine a potential severity level for this issue (1 for normal/low concern, 2 for significant/important, 3 for urgent/dangerous). Return the result strictly in JSON format with keys 'type', 'description', and 'severity' (integer 1-3)." },
              { inlineData: { mimeType: "image/jpeg", data: base64Data.split(',')[1] } }
            ]
          }
        ],
        config: {
          responseMimeType: "application/json"
        }
      });
      
      const result = JSON.parse(response.text || '{}');
      if (result.type) setIssueType(result.type);
      if (result.description) setDescription(result.description);
      if (result.severity && [1, 2, 3].includes(result.severity)) setSeverity(result.severity as any);
    } catch (error) {
      console.error("Gemini analysis failed:", error);
    } finally {
      setIsAnalyzing(false);
    }
  };

  const handleImageUpload = (img: string) => {
    setAttachedImages(prev => [...prev, img]);
    // Auto-analyze the first image to help the user
    if (attachedImages.length === 0) {
      analyzeImage(img);
    }
  };

  const handleCapture = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    if (file.size > 5 * 1024 * 1024) {
      alert("حجم الصورة كبير جداً (الأقصى 5 ميجابايت)");
      return;
    }

    const reader = new FileReader();
    reader.onload = (event) => {
      const base64 = event.target?.result as string;
      handleImageUpload(base64);
    };
    reader.readAsDataURL(file);
    
    // Clear input so same file can be captured again if needed
    if (fileInputRef.current) fileInputRef.current.value = '';
  };

  const handleVerifyLocation = () => {
    if (!navigator.geolocation) {
      alert("متصفحك لا يدعم نظام تحديد المواقع.");
      return;
    }

    setIsLocating(true);
    navigator.geolocation.getCurrentPosition(
      (position) => {
        const { latitude, longitude } = position.coords;
        setCurrentCoords({ lat: latitude, lng: longitude });
        setManualAddress(`إحداثيات: ${latitude.toFixed(4)}, ${longitude.toFixed(4)}`);
        setIsLocating(false);
      },
      (error) => {
        console.error("Geolocation error:", error);
        setIsLocating(false);
        // Fallback for demo
        const fakeLat = 15.5007 + (Math.random() - 0.5) * 0.01;
        const fakeLng = 32.5599 + (Math.random() - 0.5) * 0.01;
        setCurrentCoords({ lat: fakeLat, lng: fakeLng });
        setManualAddress("تم التحديد تقريبياً (سيتم التأكيد ميدانياً)");
      },
      { enableHighAccuracy: true, timeout: 5000, maximumAge: 0 }
    );
  };

  const nextStep = () => setStep(s => Math.min(s + 1, 3));
  const prevStep = () => setStep(s => Math.max(s - 1, 1));

  const toggleRecording = () => {
    if (isRecording) {
      setIsRecording(false);
      if (recordingTimerRef.current) clearInterval(recordingTimerRef.current);
    } else {
      setIsRecording(true);
      setRecordingDuration(0);
      recordingTimerRef.current = setInterval(() => {
        setRecordingDuration(prev => prev + 1);
      }, 1000);
    }
  };

  const formatDuration = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
  };

  const handleSubmit = async () => {
    if (!auth.currentUser) return alert("سجل دخولك أولاً لتقديم بلاغ");
    setIsSubmitting(true);

    let progressInterval: any;
    try {
      setUploadProgress(10);
      
      // Simulate real progress steps
      progressInterval = setInterval(() => {
        setUploadProgress(prev => {
          if (prev >= 90) {
            clearInterval(progressInterval);
            return 90;
          }
          return prev + 15;
        });
      }, 400);

      const location = {
        lat: currentCoords?.lat || (15.5007 + (Math.random() - 0.5) * 0.1),
        lng: currentCoords?.lng || (32.5599 + (Math.random() - 0.5) * 0.1),
        address: manualAddress || "الرياض، الخرطوم"
      };

      const docData = {
        trackingId,
        type: issueType.toLowerCase() || 'other',
        interactionType,
        description,
        location,
        severity,
        images: attachedImages,
        status: 'pending',
        currentStage: 'detected',
        reportCount: 1,
        anonymous: true,
        reporterId: auth.currentUser.uid,
        createdAt: Date.now(),
        updatedAt: Date.now(),
        regionId: 'khartoum',
        expectedResolutionAt: Date.now() + (72 * 60 * 60 * 1000), // 72h SLA
        citizenSignOff: false,
        reportedByCitizen: true
      };

      const docRef = await addDoc(collection(db, 'issues'), docData);
      setUploadProgress(100);
      clearInterval(progressInterval);

      // Award points to user
      const userRef = doc(db, 'users', auth.currentUser.uid);
      await setDoc(userRef, { 
        points: increment(100), // 100 points per report
        uid: auth.currentUser.uid,
        updatedAt: serverTimestamp()
      }, { merge: true });

      // Add initial movement log for official tracking
      await addDoc(collection(db, 'issues', docRef.id, 'movements'), {
        status: 'رصد البلاغ',
        description: `تم استلام ${interactionType === 'report' ? 'البلاغ' : interactionType === 'suggestion' ? 'المقترح' : 'الاستفسار'} في النظام وتوليد رقم المتابعة: ${trackingId}.`,
        institutionName: 'عمران | مركز التحكم الرقمي',
        timestamp: Date.now(),
        stage: 'detected'
      });

      onComplete();
    } catch (error) {
      console.error("Error submitting issue:", error);
      alert("فشل الإرسال، تأكد من الاتصال.");
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="p-8 h-full flex flex-col bg-slate-50/50 pb-40 lg:pb-12" dir="rtl">
      {/* Progress - Technical Process Indicator */}
      <div className="flex justify-between mb-16 relative px-4 lg:px-8">
        {/* Connection Line */}
        <div className="absolute top-6 left-8 right-8 h-[2px] bg-slate-200 -z-10 overflow-hidden rounded-full">
          <motion.div 
            initial={false}
            animate={{ width: `${((step - 1) / (STEPS.length - 1)) * 100}%` }}
            className="h-full bg-emerald-500 shadow-[0_0_10px_rgba(16,185,129,0.5)] transition-all duration-700"
          />
        </div>

        {STEPS.map((s) => (
          <div key={s.id} className="flex flex-col items-center gap-4 relative z-10">
            <motion.div 
              initial={false}
              animate={{ 
                scale: step === s.id ? 1.2 : step > s.id ? 1 : 0.9,
                backgroundColor: step === s.id ? '#059669' : step > s.id ? '#10b981' : '#ffffff',
                color: step >= s.id ? '#ffffff' : '#cbd5e1',
                borderColor: step >= s.id ? 'transparent' : '#f1f5f9'
              }}
              className="w-12 h-12 rounded-[1.25rem] flex items-center justify-center text-xs font-black shadow-xl border-2 transition-all duration-500"
            >
              {step > s.id ? <Check size={20} strokeWidth={3} /> : <span className="font-mono">{s.id}</span>}
            </motion.div>
            <div className="text-center">
               <span className={cn(
                 "text-[10px] font-black uppercase tracking-[0.3em] block mb-0.5 transition-colors duration-500",
                 step === s.id ? "text-slate-900" : step > s.id ? "text-emerald-600" : "text-slate-300"
               )}>{s.title}</span>
               {step === s.id && (
                 <motion.div layoutId="active-dot" className="w-1.5 h-1.5 bg-emerald-500 rounded-full mx-auto" />
               )}
            </div>
          </div>
        ))}
      </div>

      {/* Form Content Area */}
      <div className="flex-1 overflow-y-auto overflow-x-hidden px-2">
        <AnimatePresence mode="wait">
          {step === 1 && (
            <motion.div
              key="step1"
              initial={{ opacity: 0, x: -30 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: 30 }}
              className="space-y-10"
            >
              <div className="space-y-3 text-right">
                <div className="flex items-center gap-2 justify-end mb-1">
                   <div className="w-8 h-[1px] bg-emerald-500" />
                   <span className="text-[10px] font-black text-emerald-600 uppercase tracking-[0.3em]">INPUT MODULE // MULTIMEDIA</span>
                </div>
                <h2 className="text-3xl font-black tracking-tight text-slate-900 leading-none">التوثيق الميداني</h2>
                <p className="text-xs text-slate-400 font-medium italic">استخدم الكاميرا أو التسجيل الصوتي لرصد الحالة بدقة متناهية.</p>
              </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
                  <input 
                    type="file"
                    ref={fileInputRef}
                    accept="image/*"
                    capture="environment"
                    className="hidden"
                    onChange={handleCapture}
                  />
                  <button 
                    disabled={isAnalyzing}
                    className="aspect-square lg:aspect-video bento-inner flex flex-col items-center justify-center gap-6 text-slate-400 hover:text-emerald-500 hover:border-emerald-500 group transition-all duration-500 border-slate-900 border-2 bg-white relative overflow-hidden shadow-[8px_8px_0_0_#1e293b]"
                    onClick={() => fileInputRef.current?.click()}
                  >
                    {isAnalyzing ? (
                      <motion.div 
                        animate={{ rotate: 360 }}
                        transition={{ repeat: Infinity, duration: 2, ease: "linear" }}
                        className="text-emerald-500"
                      >
                        <Sparkles size={56} strokeWidth={1} />
                      </motion.div>
                    ) : (
                      <div className="p-6 rounded-[2.5rem] bg-slate-50 group-hover:bg-emerald-50 transition-colors">
                         <Camera size={48} strokeWidth={1} />
                      </div>
                    )}
                    <div className="text-center">
                       <span className="text-[12px] font-black uppercase tracking-[0.2em] block mb-1">
                         {isAnalyzing ? 'تحليل ذكي...' : 'التقاط صورة'}
                       </span>
                       <span className="text-[9px] font-bold text-slate-300 uppercase tracking-widest">{attachedImages.length} صور مرفقة</span>
                    </div>
                    {isAnalyzing && (
                      <motion.div 
                        initial={{ width: 0 }}
                        animate={{ width: "100%" }}
                        className="absolute bottom-0 left-0 h-1 bg-emerald-500 shadow-[0_0_10px_#10b981]"
                      />
                    )}
                  </button>
                <button 
                  className={cn(
                    "aspect-square bento-inner flex flex-col items-center justify-center gap-6 transition-all duration-500 border-dashed border-2 bg-white group relative overflow-hidden",
                    isRecording 
                      ? "bg-rose-50 border-rose-500 text-rose-500" 
                      : "border-slate-200 text-slate-400 hover:text-emerald-500 hover:border-emerald-500"
                  )}
                  onClick={toggleRecording}
                >
                  {isRecording && (
                    <div className="absolute top-0 inset-x-0 h-1 flex gap-1 px-1">
                      {[...Array(20)].map((_, i) => (
                        <motion.div
                          key={i}
                          animate={{ height: [4, Math.random() * 16 + 4, 4] }}
                          transition={{ 
                            repeat: Infinity, 
                            duration: 0.5, 
                            delay: i * 0.05 
                          }}
                          className="flex-1 bg-rose-500 rounded-full"
                        />
                      ))}
                    </div>
                  )}
                  <div className={cn(
                    "p-6 rounded-[2.5rem] transition-colors",
                    isRecording ? "bg-rose-100" : "bg-slate-50 group-hover:bg-emerald-50"
                  )}>
                     <Mic size={48} strokeWidth={1} />
                  </div>
                  <div className="text-center">
                     <span className="text-[12px] font-black uppercase tracking-[0.2em] block">
                       {isRecording ? formatDuration(recordingDuration) : 'تسجيل إفادة'}
                     </span>
                     {isRecording && (
                       <span className="text-[9px] font-bold text-rose-400 uppercase tracking-widest mt-1 block animate-pulse">RECORDING_SYNC</span>
                     )}
                  </div>
                </button>
              </div>

              {attachedImages.length > 0 && (
                <div className="space-y-4">
                  <div className="flex justify-between items-center px-1">
                    <span className="text-[10px] font-black text-slate-400 uppercase tracking-[0.3em]">VISUAL EVIDENCE CORRIDOR</span>
                    <ScanSearch size={14} className="text-slate-300" />
                  </div>
                  <div className="flex gap-4 overflow-x-auto pb-4 no-scrollbar snap-x pr-1">
                    {attachedImages.map((img, idx) => (
                      <motion.div 
                        key={idx} 
                        initial={{ opacity: 0, scale: 0.8 }}
                        animate={{ opacity: 1, scale: 1 }}
                        className="relative w-48 h-32 shrink-0 rounded-[2rem] overflow-hidden snap-start shadow-[0_15px_35px_rgba(0,0,0,0.1)] group border-2 border-white"
                      >
                        <img src={img} alt="Preview" className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-110" />
                        <div className="absolute inset-0 bg-black/20 opacity-0 group-hover:opacity-100 transition-opacity" />
                        <button 
                          onClick={() => setAttachedImages(prev => prev.filter((_, i) => i !== idx))}
                          className="absolute top-3 left-3 w-8 h-8 bg-white/20 hover:bg-rose-500 text-white rounded-xl flex items-center justify-center backdrop-blur-md transition-all shadow-xl"
                        >
                          <X size={16} />
                        </button>
                      </motion.div>
                    ))}
                  </div>
                </div>
              )}

              <div className="p-8 bento-inner bg-emerald-600 text-white border-transparent flex items-center gap-6 shadow-[0_25px_50px_rgba(5,150,105,0.2)]">
                <div className="w-14 h-14 rounded-3xl bg-white/20 flex items-center justify-center shrink-0 shadow-[0_0_20px_rgba(255,255,255,0.1)] text-white rotate-3">
                  <MapPin size={28} />
                </div>
                <div className="text-right flex-1">
                  <p className="text-[10px] font-mono font-black text-emerald-100 uppercase tracking-[0.4em] mb-1">GEOLOCATION // VERIFIED</p>
                  <p className="text-base font-black tracking-tight">{manualAddress || 'جاري تحديد الموضع...'}</p>
                </div>
              </div>
            </motion.div>
          )}

          {step === 2 && (
            <motion.div
              key="step2"
              initial={{ opacity: 0, x: 50 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -50 }}
              className="space-y-10"
            >
              <div className="space-y-3 text-right">
                <div className="flex items-center gap-2 justify-end mb-1">
                   <div className="w-8 h-[1px] bg-emerald-500" />
                   <span className="text-[10px] font-black text-emerald-600 uppercase tracking-[0.3em]">SYSTEM LOG // CLASSIFICATION</span>
                </div>
                <h2 className="text-3xl font-black tracking-tight text-slate-900 leading-none">تفاصيل البلاغ</h2>
                <p className="text-xs text-slate-400 font-medium italic">أدخل البيانات المطلوبة لتمكين النظام من توجيه البلاغ بدقة.</p>
              </div>

              <div className="space-y-10">
                <div className="space-y-5">
                  <label className="text-[11px] font-black text-slate-400 uppercase tracking-[0.3em] text-right block mb-2 px-1 italic">OBJECTIVE TYPE</label>
                  <div className="flex gap-3 p-2 bg-slate-50/80 rounded-[2.5rem] border border-slate-100 shadow-inner">
                    {[
                      { id: 'report', label: 'بلاغ مباشر' },
                      { id: 'suggestion', label: 'مقترح فني' },
                      { id: 'inquiry', label: 'استفسار نظام' }
                    ].map(tab => (
                      <button
                        key={tab.id}
                        type="button"
                        onClick={() => setInteractionType(tab.id as any)}
                        className={cn(
                          "flex-1 py-4 rounded-[2rem] text-[11px] font-black uppercase tracking-[0.1em] transition-all duration-300",
                          interactionType === tab.id 
                            ? "bg-emerald-600 text-white shadow-2xl scale-[1.02]" 
                            : "text-slate-400 hover:bg-white hover:text-slate-600"
                        )}
                      >
                        {tab.label}
                      </button>
                    ))}
                  </div>
                </div>

                <div className="space-y-5">
                  <label className="text-[11px] font-black text-slate-400 uppercase tracking-[0.3em] text-right block mb-2 px-1 italic">SECTOR CATEGORIZATION</label>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    {CATEGORIES.map(cat => (
                      <button
                        key={cat.id}
                        onClick={() => setIssueType(cat.id)}
                        className={cn(
                          "px-6 py-8 rounded-[2.5rem] border-2 flex items-center gap-6 text-sm font-black transition-all duration-500 active:scale-95 group",
                          issueType === cat.id 
                            ? "bg-slate-900 border-slate-950 text-white shadow-[12px_12px_0_0_#10b981] scale-[1.02]" 
                            : "bg-white border-slate-100 text-slate-500 hover:border-slate-900"
                        )}
                      >
                         <span className={cn(
                           "p-3 rounded-2xl flex items-center justify-center shrink-0 transition-transform duration-500 group-hover:rotate-6",
                           issueType === cat.id ? "bg-white/10" : "bg-slate-50"
                         )}>
                           {React.cloneElement(cat.icon as any, { size: 20 })}
                         </span>
                         <span className="uppercase tracking-tight">{cat.label}</span>
                      </button>
                    ))}
                  </div>
                </div>

                <div className="space-y-5">
                   <div className="flex justify-between items-center px-1">
                      <label className="text-[11px] font-black text-slate-400 uppercase tracking-[0.3em] italic">TECHNICAL DESCRIPTION</label>
                      <HelpCircle size={14} className="text-slate-300 animate-pulse" />
                   </div>
                  <textarea 
                    rows={4}
                    placeholder="وصف تقني موجز للحالة المرفوعة..."
                    className="w-full px-8 py-6 rounded-[3rem] border border-slate-100 bg-white text-sm font-medium focus:ring-[15px] focus:ring-emerald-500/5 focus:border-emerald-500 outline-none transition-all text-right resize-none placeholder:text-slate-200 shadow-sm"
                    value={description}
                    onChange={(e) => setDescription(e.target.value)}
                  />
                </div>
              </div>
            </motion.div>
          )}

          {step === 3 && (
            <motion.div
              key="step3"
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 1.1 }}
              className="space-y-10"
            >
              <div className="space-y-3 text-right">
                <div className="flex items-center gap-2 justify-end mb-1">
                   <div className="w-8 h-[1px] bg-emerald-500" />
                   <span className="text-[10px] font-black text-emerald-600 uppercase tracking-[0.3em]">FINAL VALIDATION // COMMIT</span>
                </div>
                <h2 className="text-3xl font-black tracking-tight text-slate-900 leading-none">تأكيد الإرسال</h2>
                <p className="text-xs text-slate-400 font-medium italic">يرجى مراجعة البيانات بعناية قبل الاعتماد النهائي في السجل الوطني.</p>
              </div>

              <div className="bento-inner border-slate-100 bg-white !p-10 space-y-8 text-right relative overflow-hidden shadow-[0_30px_60px_rgba(0,0,0,0.05)]">
                <div className="absolute top-0 right-0 w-48 h-48 bg-emerald-500/5 blur-[80px] rounded-full -translate-y-1/2 translate-x-1/2" />
                
                <div className="flex justify-between items-center mb-6">
                  <div className="flex flex-col items-start font-mono">
                     <span className="text-[8px] font-black text-slate-300 uppercase tracking-widest mb-1">DOC_ID // SYSTEM</span>
                     <span className="px-4 py-2 bg-emerald-600 text-white rounded-xl text-[11px] font-black uppercase tracking-[0.2em] shadow-xl border border-emerald-500/30">
                       {trackingId}
                     </span>
                  </div>
                  <div className="w-16 h-16 rounded-[2rem] bg-emerald-50 flex items-center justify-center text-emerald-600 shadow-inner">
                     <CheckCircle2 size={32} />
                  </div>
                </div>

                <div className="space-y-6 relative z-10 border-t border-slate-50 pt-8">
                  <div className="flex justify-between items-start flex-row-reverse">
                    <div>
                      <h3 className="font-black text-2xl text-slate-900 mb-1">{CATEGORIES.find(c => c.id === issueType)?.label || 'بلاغ مسجل'}</h3>
                      <div className="flex items-center gap-2 justify-end text-emerald-600 font-bold italic tracking-tighter">
                         <MapPin size={14} />
                         <p className="text-sm">{manualAddress || 'الرياض، الخرطوم'}</p>
                      </div>
                    </div>
                    <div className={cn(
                      "px-6 py-2 text-[10px] font-black rounded-full uppercase tracking-[0.3em] shadow-lg",
                      severity === 3 ? "bg-rose-500 text-white shadow-rose-200" : "bg-emerald-600 text-white shadow-emerald-200"
                    )}>
                      {severity === 3 ? 'URGENT // عاجل' : 'NORMAL // عادي'}
                    </div>
                  </div>
                  <p className="text-sm text-slate-500 leading-[1.8] font-medium border-r-4 border-emerald-500 pr-6 mr-1 italic bg-slate-50/50 py-4 rounded-xl">{description || 'لا يوجد تفاصيل إضافية مسجلة.'}</p>
                </div>
              </div>

              <div className="p-6 rounded-[2.5rem] bg-white border border-slate-100 flex items-center justify-between shadow-sm">
                <div className="flex items-center gap-4">
                   <div className="w-12 h-12 rounded-2xl bg-amber-50 flex items-center justify-center text-amber-600 shadow-inner">
                     <ShieldCheck size={24} />
                   </div>
                   <div className="text-left">
                      <span className="text-[10px] font-black text-slate-900 uppercase tracking-[0.2em] block">PROTOCOL // ANONYMOUS</span>
                      <span className="text-[9px] font-bold text-slate-400 uppercase">ENCRYPTED IDENTITY</span>
                   </div>
                </div>
                <div className="w-4 h-4 rounded-full bg-emerald-500 ring-4 ring-emerald-50" />
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </div>

      {/* Action Footer Buttons */}
      <footer className="pt-10 flex gap-6">
        {step > 1 && (
          <button 
            onClick={prevStep}
            className="w-32 py-6 bg-white border-2 border-slate-100 text-slate-400 font-black rounded-[2.5rem] flex items-center justify-center transition-all duration-300 active:scale-95 text-[11px] uppercase tracking-[0.3em] hover:border-emerald-600 hover:text-emerald-600 shadow-sm"
          >
            عودة
          </button>
        )}
        <button 
          onClick={step === 3 ? handleSubmit : nextStep}
          disabled={isSubmitting || (step === 2 && (!issueType || !description || !manualAddress))}
          className="flex-1 py-6 bg-emerald-600 text-white font-black rounded-[2.5rem] flex items-center justify-center gap-4 shadow-[0_20px_50px_rgba(5,150,105,0.3)] transition-all duration-500 active:scale-[0.98] disabled:opacity-30 text-[12px] uppercase tracking-[0.4em] relative overflow-hidden group"
        >
          {isSubmitting && (
            <motion.div 
              initial={{ width: 0 }}
              animate={{ width: `${uploadProgress}%` }}
              className="absolute inset-0 bg-emerald-500 transition-all duration-500"
            />
          )}
          {isSubmitting ? (
            <div className="flex items-center gap-3 relative z-10">
               <Loader2 className="animate-spin text-white" size={24} />
               <span className="font-mono text-[10px] tracking-widest">TRANSMITTING // {uploadProgress}%</span>
            </div>
          ) : (
            <>
               <span className="relative z-10">{step === 3 ? 'اعتماد وإرسال البلاغ' : 'الخطوة التالية'}</span>
               <ArrowRight size={20} strokeWidth={3} className={cn("transition-transform duration-500 group-hover:translate-x-2 rotate-180", step === 3 ? "opacity-0" : "opacity-100")} />
               <Send size={20} strokeWidth={3} className={cn("transition-transform duration-500 rotate-180 absolute right-8 group-hover:-translate-y-1 group-hover:translate-x-1", step === 3 ? "opacity-100" : "opacity-0")} />
            </>
          )}
        </button>
      </footer>
    </div>
  );
}
